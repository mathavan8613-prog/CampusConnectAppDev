import { state } from './state.js';
import { guard } from './guards.js';
const routes = {};
export const register = (path, role, mount, pending = false) => { routes[path] = { role, mount, pending }; };
export async function navigate() {
  const path = location.hash.slice(1) || '/';
  const route = routes[path] || routes['/'];
  const to = guard(route, state, path);
  if (to && to !== path) { location.hash = to; return; }
  const app = document.getElementById('app');
  try { await route.mount(app); }
  catch (e) { console.error(e); app.innerHTML = '<p class="p-6 text-red-700">Something went wrong. Reload and try again.</p>'; }
}
export const start = () => { addEventListener('hashchange', navigate); navigate(); };

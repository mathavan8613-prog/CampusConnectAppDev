export const home = { student: '/student', teacher: '/teacher', admin: '/admin' };
const homeFor = s => (s.role === 'teacher' && s.status !== 'active') ? '/pending' : (home[s.role] || '/login');
/** Returns a path to redirect to, or null when access is allowed. UI guard only: Firestore rules are the real boundary. */
export function guard(route, s, path) {
  if (s.registering) return null;
  if (!route.role) return (s.user && ['/', '/login', '/register', '/register-teacher'].includes(path)) ? homeFor(s) : null;
  if (!s.user) return '/login';
  if (s.role !== route.role) return homeFor(s);
  if (s.role === 'teacher' && s.status !== 'active' && !route.pending) return '/pending';
  return null;
}

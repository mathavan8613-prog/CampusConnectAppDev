// Minimal in-memory session state. Cleared on logout so no private data lingers.
export const state = { user: null, role: null, status: null, ready: false, registering: false };
export function setSession(user, s) { Object.assign(state, { user, role: s?.role ?? null, status: s?.status ?? null, ready: true }); }
export function clearState() { Object.assign(state, { user: null, role: null, status: null, ready: true }); }

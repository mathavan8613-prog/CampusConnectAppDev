import { state } from '../../app/state.js';
import { layout } from '../../components/layout.js';
import { crudView } from '../../components/crud-view.js';
import { toast } from '../../components/toast.js';
import { esc, isPhone, isHttps } from '../../utils/validators.js';
import { fmtTs } from '../../utils/date-time.js';
import { subjectMap, list, where } from '../../services/base.js';
import { getProfile, updateContact } from '../../services/student.service.js';
import { forStudent } from '../../services/attendance.service.js';
import * as timetable from '../../services/timetable.service.js';
import * as exams from '../../services/examination.service.js';
import * as results from '../../services/results.service.js';
import * as materials from '../../services/materials.service.js';
import * as events from '../../services/events.service.js';
import * as notifications from '../../services/notifications.service.js';
import { DEMO, orDemo, subjectLabel } from '../../utils/demo-data.js';

const items = [['/student', 'Profile'], ['/student/subjects', 'Subjects'], ['/student/attendance', 'Attendance'], ['/student/timetable', 'Timetable'], ['/student/exams', 'Exams'],
  ['/student/results', 'Results'], ['/student/materials', 'Materials'], ['/student/events', 'Events'], ['/student/notifications', 'Notifications']].map(([path, label]) => ({ path, label }));
const page = (path, fn) => ({ role: 'student', mount: async app => {
  const el = layout(app, items, path);
  try { await fn(el, state.user.uid); } catch (e) { console.error(e); toast(e.message, 'error'); } } });
const input = 'mt-1 w-full rounded-md border border-slate-300 px-2 py-1.5 text-sm';

export const routes = {
  '/student': page('/student', async (el, uid) => {
    const p = await getProfile(uid);
    if (!p) { el.innerHTML = '<p>No student record found.</p>'; return; }
    el.innerHTML = `<h1 class="mb-4 text-xl font-semibold text-indigo-950">My profile</h1>
      <dl class="grid gap-3 rounded-xl border border-slate-200 bg-white p-4 text-sm sm:grid-cols-2">${[['Name', p.displayName], ['Register no.', p.registerNo], ['Department', p.departmentId], ['Degree', p.degree], ['Year', p.year], ['Semester', p.semester], ['Section', p.section]]
        .map(([k, v]) => `<div><dt class="text-slate-500">${k}</dt><dd class="font-medium">${esc(v)}</dd></div>`).join('')}</dl>
      <form id="pf" class="mt-4 max-w-sm space-y-3 rounded-xl border border-slate-200 bg-white p-4"><p class="text-xs text-slate-500">You can update contact details only.</p>
        <label class="block text-xs font-medium text-slate-600">Phone<input name="phone" value="${esc(p.phone)}" class="${input}"/></label>
        <label class="block text-xs font-medium text-slate-600">Photo URL (https)<input name="photoURL" value="${esc(p.photoURL)}" class="${input}"/></label>
        <button class="rounded-md bg-indigo-800 px-4 py-2 text-sm font-medium text-white">Save changes</button></form>`;
    el.querySelector('#pf').onsubmit = async e => { e.preventDefault(); const f = new FormData(e.target), phone = f.get('phone').trim(), photoURL = f.get('photoURL').trim();
      if (!isPhone(phone)) return toast('Enter a valid phone number.', 'error'); if (!isHttps(photoURL)) return toast('Photo URL must start with https://', 'error');
      try { await updateContact(uid, { phone, photoURL }); toast('Profile updated'); } catch (err) { toast(err.message, 'error'); } };
  }),
  '/student/subjects': page('/student/subjects', async (el, uid) => { const p = await getProfile(uid);
    await crudView(el, { title: 'Subjects', csvName: 'subjects.csv', load: () => orDemo(() => list('subjects', where('departmentId', '==', p.departmentId)), DEMO.subjects),
      cols: [{ key: 'code', label: 'Code' }, { key: 'name', label: 'Subject' }, { key: 'departmentId', label: 'Dept' }, { key: 'semester', label: 'Sem' }, { key: 'credits', label: 'Credits' }] }); }),
  '/student/attendance': page('/student/attendance', async (el, uid) => { const sm = await subjectMap();
    await crudView(el, { title: 'My attendance', csvName: 'my-attendance.csv', load: () => orDemo(async () => (await forStudent(uid)).sort((a, b) => b.classDate.localeCompare(a.classDate)), DEMO.attendance),
      cols: [{ key: 'classDate', label: 'Date' }, { key: 'subjectId', label: 'Subject', fmt: v => subjectLabel(sm, v) }, { key: 'status', label: 'Status' }],
      summary: rows => { const by = {}; rows.forEach(r => { (by[r.subjectId] ??= { t: 0, p: 0 }).t++; if (r.status === 'present') by[r.subjectId].p++; });
        return Object.entries(by).map(([k, v]) => `${esc(sm[k]?.code || k)}: ${Math.round(v.p / v.t * 100)}%`).join(' | ') || 'No attendance recorded yet.'; } }); }),
  '/student/timetable': page('/student/timetable', async (el, uid) => { const [p, sm] = [await getProfile(uid), await subjectMap()];
    await crudView(el, { title: 'Timetable', csvName: 'timetable.csv', load: () => orDemo(() => timetable.publishedFor(p), DEMO.timetable),
      cols: [{ key: 'day', label: 'Day' }, { key: 'startTime', label: 'From' }, { key: 'endTime', label: 'To' }, { key: 'subjectId', label: 'Subject', fmt: v => subjectLabel(sm, v) }, { key: 'room', label: 'Room' }] }); }),
  '/student/exams': page('/student/exams', async (el, uid) => { const [p, sm] = [await getProfile(uid), await subjectMap()];
    await crudView(el, { title: 'Exam schedule', csvName: 'exams.csv', load: () => orDemo(() => exams.publishedFor(p), DEMO.exams),
      cols: [{ key: 'examDate', label: 'Date' }, { key: 'startTime', label: 'From' }, { key: 'endTime', label: 'To' }, { key: 'subjectId', label: 'Subject', fmt: v => subjectLabel(sm, v) }, { key: 'room', label: 'Room' }] }); }),
  '/student/results': page('/student/results', async (el, uid) => { const sm = await subjectMap();
    await crudView(el, { title: 'My results', csvName: 'my-results.csv', load: () => orDemo(() => results.mine(uid), DEMO.results),
      cols: [{ key: 'subjectId', label: 'Subject', fmt: v => subjectLabel(sm, v) }, { key: 'marks', label: 'Marks' }, { key: 'maxMarks', label: 'Out of' }, { key: 'grade', label: 'Grade' }] }); }),
  '/student/materials': page('/student/materials', async (el, uid) => { const [p, sm] = [await getProfile(uid), await subjectMap()];
    await crudView(el, { title: 'Study materials', load: () => orDemo(() => materials.publishedFor(p), DEMO.materials),
      cols: [{ key: 'title', label: 'Title' }, { key: 'subjectId', label: 'Subject', fmt: v => subjectLabel(sm, v) },
        { label: 'File', html: r => `<a href="${esc(r.downloadURL)}" target="_blank" rel="noopener" class="text-indigo-700 underline">Download</a>` }] }); }),
  '/student/events': page('/student/events', async (el, uid) => {
    await crudView(el, { title: 'Events', csvName: 'events.csv',
      load: () => orDemo(async () => { const [ev, regs] = [await events.published(), new Set((await events.myRegistrations(uid)).map(r => r.eventId))];
        return ev.map(e => ({ ...e, registered: regs.has(e.id) ? 'Yes' : 'No' })).sort((a, b) => a.eventDate.localeCompare(b.eventDate)); }, DEMO.events),
      cols: [{ key: 'eventDate', label: 'Date' }, { key: 'title', label: 'Event' }, { key: 'venue', label: 'Venue' }, { key: 'description', label: 'Details' }, { key: 'registered', label: 'Registered' }],
      actions: [{ label: 'Register', fn: r => events.registerFor(r.id, uid) }, { label: 'Cancel', fn: r => events.cancelRegistration(r.id, uid) }] }); }),
  '/student/notifications': page('/student/notifications', async (el, uid) => {
    await crudView(el, { title: 'Notifications', load: () => orDemo(async () => (await notifications.mine(uid)).sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0)), DEMO.notifications),
      cols: [{ key: 'title', label: 'Title' }, { key: 'body', label: 'Message' }, { key: 'createdAt', label: 'Sent', fmt: fmtTs }] }); }),
};

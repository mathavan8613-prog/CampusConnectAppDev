import { login, resetPassword, registerStudent, registerTeacher, logout } from '../../services/auth.service.js';
import { toast } from '../../components/toast.js';
import { navigate } from '../../app/router.js';
import { isEmail, validateAccount, isPhone, authError, esc } from '../../utils/validators.js';

const inp = 'mt-1 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm';
const f = (n, l, t = 'text', v = '') => `<label class="block text-xs font-medium text-slate-600">${l}<input name="${n}" type="${t}" value="${esc(v)}" class="${inp}" required ${t === 'password' ? 'minlength="8" autocomplete="new-password"' : ''}/></label>`;
const card = (title, body, foot) => `<main class="mx-auto mt-8 max-w-md rounded-2xl border border-slate-200 bg-white p-6 shadow-sm md:mt-14">
  <h1 class="mb-4 text-xl font-semibold text-indigo-950">${title}</h1>${body}<p class="mt-4 text-center text-sm text-slate-500">${foot}</p></main>`;
const btn = t => `<button class="mt-2 w-full rounded-md bg-indigo-800 py-2 text-sm font-medium text-white hover:bg-indigo-900 disabled:opacity-50">${t}</button>`;
const data = form => Object.fromEntries(new FormData(form).entries());

async function submit(form, fn) {
  const b = form.querySelector('button'); b.disabled = true;
  try { await fn(data(form)); } catch (e) { toast(authError(e), 'error'); } finally { b.disabled = false; }
}
function signupForm(app, title, fields, foot, fn) {
  app.innerHTML = card(title, `<form class="space-y-3">${fields}${btn('Create account')}</form>`, foot);
  app.querySelector('form').onsubmit = e => { e.preventDefault(); submit(e.target, async v => {
    const errs = validateAccount(v); if (v.phone !== undefined && !isPhone(v.phone)) errs.push('Enter a valid phone number.');
    if (errs.length) return toast(errs[0], 'error');
    await fn(v); toast('Account created'); navigate(); }); };
}
export const routes = {
  '/login': { role: null, mount: app => {
    app.innerHTML = card('Log in', `<form class="space-y-3">${f('email', 'Email', 'email')}${f('password', 'Password', 'password')}${btn('Log in')}</form>
      <button id="forgot" class="mt-3 block w-full text-center text-sm text-indigo-700 underline">Forgot password?</button>`,
      'New here? <a class="text-indigo-700 underline" href="#/register">Student sign-up</a> or <a class="text-indigo-700 underline" href="#/register-teacher">teacher request</a>');
    const form = app.querySelector('form');
    form.querySelector('[name=password]').setAttribute('autocomplete', 'current-password');
    form.onsubmit = e => { e.preventDefault(); submit(form, v => isEmail(v.email) ? login(v.email, v.password) : Promise.reject(new Error('Enter a valid email address.'))); };
    app.querySelector('#forgot').onclick = async () => {
      const email = form.email.value.trim(); if (!isEmail(email)) return toast('Enter your email first.', 'error');
      try { await resetPassword(email); toast('If that account exists, a reset email was sent.'); } catch (e) { toast(authError(e), 'error'); } };
  } },
  '/register': { role: null, mount: app => signupForm(app, 'Student sign-up',
    f('displayName', 'Full name') + f('email', 'Email', 'email') + f('password', 'Password', 'password') + f('registerNo', 'Register number') +
    f('departmentId', 'Department code', 'text', 'CSE') + f('degree', 'Degree', 'text', 'B.E.') + f('year', 'Year', 'number', '1') + f('semester', 'Semester', 'number', '1') +
    f('section', 'Section', 'text', 'A') + '<label class="block text-xs font-medium text-slate-600">Phone (optional)<input name="phone" class="' + inp + '"/></label>',
    'Have an account? <a class="text-indigo-700 underline" href="#/login">Log in</a>', registerStudent) },
  '/register-teacher': { role: null, mount: app => signupForm(app, 'Request teacher access',
    f('displayName', 'Full name') + f('email', 'Email', 'email') + f('password', 'Password', 'password') + f('facultyId', 'Faculty ID') +
    f('departmentId', 'Department code', 'text', 'CSE') + f('designation', 'Designation'),
    'An admin must approve your account before you can sign in to the teacher portal.', registerTeacher) },
  '/pending': { role: 'teacher', pending: true, mount: app => {
    app.innerHTML = card('Waiting for approval', '<p class="text-sm text-slate-600">Your teacher account has not been approved yet, or was declined. Contact your department admin. You will get access as soon as it is approved.</p><button id="lo" class="mt-4 text-sm text-indigo-700 underline">Log out</button>', '');
    app.querySelector('#lo').onclick = logout; } },
};

import { layout } from '../../components/layout.js';
import { crudView } from '../../components/crud-view.js';
import { toast } from '../../components/toast.js';
import { list, add, save, remove } from '../../services/base.js';
import { pendingTeachers, approvedTeachers, setApproval } from '../../services/teacher.service.js';

const items = [['/admin', 'Teacher approvals'], ['/admin/departments', 'Departments'], ['/admin/subjects', 'Subjects'], ['/admin/assignments', 'Assignments'], ['/admin/students', 'Students']].map(([path, label]) => ({ path, label }));
const page = (path, fn) => ({ role: 'admin', mount: async app => { const el = layout(app, items, path); try { await fn(el); } catch (e) { console.error(e); toast(e.message, 'error'); } } });
const yn = v => v ? 'Yes' : 'No';

export const routes = {
  '/admin': page('/admin', el => crudView(el, { title: 'Pending teacher requests',
    load: pendingTeachers, cols: [{ key: 'displayName', label: 'Name' }, { key: 'email', label: 'Email' }, { key: 'facultyId', label: 'Faculty ID' }, { key: 'departmentId', label: 'Dept' }, { key: 'designation', label: 'Designation' }],
    actions: [{ label: 'Approve', fn: r => setApproval(r.id, true) }, { label: 'Reject', fn: r => setApproval(r.id, false) }] })),

  '/admin/departments': page('/admin/departments', el => crudView(el, { title: 'Departments',
    fields: [{ name: 'name', label: 'Name' }, { name: 'code', label: 'Code' }, { name: 'active', label: 'Active', type: 'checkbox' }],
    load: () => list('departments'), save: v => add('departments', { name: v.name, code: v.code.toUpperCase(), active: v.active }), remove: r => remove('departments', r.id),
    cols: [{ key: 'code', label: 'Code' }, { key: 'name', label: 'Name' }, { key: 'active', label: 'Active', fmt: yn }] })),

  '/admin/subjects': page('/admin/subjects', async el => { const deps = await list('departments');
    await crudView(el, { title: 'Subjects',
      fields: [{ name: 'name', label: 'Name' }, { name: 'code', label: 'Code' }, { name: 'departmentId', label: 'Department', type: 'select', options: deps.map(d => ({ value: d.code, label: d.code })) },
        { name: 'semester', label: 'Semester', type: 'number' }, { name: 'credits', label: 'Credits', type: 'number' }],
      load: () => list('subjects'), save: v => add('subjects', v), remove: r => remove('subjects', r.id),
      cols: [{ key: 'code', label: 'Code' }, { key: 'name', label: 'Name' }, { key: 'departmentId', label: 'Dept' }, { key: 'semester', label: 'Sem' }, { key: 'credits', label: 'Credits' }] }); }),

  '/admin/assignments': page('/admin/assignments', async el => { const [ts, subs] = [await approvedTeachers(), await list('subjects')];
    const tn = Object.fromEntries(ts.map(t => [t.id, t.displayName])), sn = Object.fromEntries(subs.map(s => [s.id, s]));
    await crudView(el, { title: 'Teacher assignments',
      fields: [{ name: 'teacherUid', label: 'Teacher', type: 'select', options: ts.map(t => ({ value: t.id, label: t.displayName })) },
        { name: 'subjectId', label: 'Subject', type: 'select', options: subs.map(s => ({ value: s.id, label: `${s.code} ${s.name}` })) }, { name: 'section', label: 'Section' }],
      // ID teacherUid_subjectId is what Firestore rules use to check "assigned".
      load: () => list('teacherAssignments'), remove: r => remove('teacherAssignments', r.id),
      save: v => { const s = sn[v.subjectId]; return save('teacherAssignments', `${v.teacherUid}_${v.subjectId}`, { teacherUid: v.teacherUid, subjectId: v.subjectId, departmentId: s.departmentId, semester: s.semester, section: v.section.toUpperCase() }); },
      cols: [{ key: 'teacherUid', label: 'Teacher', fmt: v => tn[v] || v }, { key: 'subjectId', label: 'Subject', fmt: v => sn[v]?.code || v }, { key: 'semester', label: 'Sem' }, { key: 'section', label: 'Section' }] }); }),

  '/admin/students': page('/admin/students', el => crudView(el, { title: 'Student directory', csvName: 'students.csv',
    load: () => list('students'), remove: r => remove('students', r.id),
    cols: [{ key: 'registerNo', label: 'Register no.' }, { key: 'displayName', label: 'Name' }, { key: 'departmentId', label: 'Dept' }, { key: 'semester', label: 'Sem' }, { key: 'section', label: 'Section' }, { key: 'email', label: 'Email' }] })),
};

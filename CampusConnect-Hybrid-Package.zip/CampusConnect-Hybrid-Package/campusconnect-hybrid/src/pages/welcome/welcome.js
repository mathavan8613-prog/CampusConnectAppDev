export const routes = { '/': { role: null, mount: app => {
  app.innerHTML = `<main class="mx-auto flex min-h-screen max-w-3xl flex-col justify-center px-6 py-12">
    <h1 class="text-4xl font-semibold text-indigo-950">CampusConnect</h1>
    <p class="mt-3 max-w-xl text-slate-600">Attendance, timetables, exams, results, study materials and events for your department, in one installable app.</p>
    <div class="mt-8 flex flex-wrap gap-3">
      <a href="#/login" class="rounded-md bg-indigo-800 px-5 py-2.5 text-sm font-medium text-white hover:bg-indigo-900">Log in</a>
      <a href="#/register" class="rounded-md border border-slate-300 bg-white px-5 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-100">Student sign-up</a>
      <a href="#/register-teacher" class="rounded-md border border-slate-300 bg-white px-5 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-100">Request teacher access</a>
    </div></main>`; } } };

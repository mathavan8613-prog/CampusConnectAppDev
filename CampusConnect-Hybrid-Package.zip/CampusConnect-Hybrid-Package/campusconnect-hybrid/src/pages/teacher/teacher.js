import { state } from '../../app/state.js';
import { layout } from '../../components/layout.js';
import { crudView } from '../../components/crud-view.js';
import { toast } from '../../components/toast.js';
import { esc } from '../../utils/validators.js';
import { today, DAYS } from '../../utils/date-time.js';
import { downloadCsv } from '../../utils/csv-export.js';
import { list } from '../../services/base.js';
import { myAssignments } from '../../services/teacher.service.js';
import { listByClass } from '../../services/student.service.js';
import { markAttendance, forClassDate } from '../../services/attendance.service.js';
import * as timetable from '../../services/timetable.service.js';
import * as exams from '../../services/examination.service.js';
import * as results from '../../services/results.service.js';
import * as materials from '../../services/materials.service.js';
import * as events from '../../services/events.service.js';

const items = [['/teacher', 'Students'], ['/teacher/attendance', 'Attendance'], ['/teacher/timetable', 'Timetable'], ['/teacher/exams', 'Exams'],
  ['/teacher/results', 'Results'], ['/teacher/materials', 'Materials'], ['/teacher/events', 'Events']].map(([path, label]) => ({ path, label }));
const page = (path, fn) => ({ role: 'teacher', mount: async app => {
  const el = layout(app, items, path);
  try { await fn(el, state.user.uid, await ctx(state.user.uid)); } catch (e) { console.error(e); toast(e.message, 'error'); } } });

/** Assigned classes only: every dropdown is built from the teacher's own assignments. */
async function ctx(uid) {
  const [as, subs] = await Promise.all([myAssignments(uid), list('subjects')]);
  const by = Object.fromEntries(subs.map(s => [s.id, s]));
  const label = a => `${by[a.subjectId]?.code || a.subjectId} - Sem ${a.semester} ${a.section}`;
  return { as, by, find: id => as.find(a => a.subjectId === id), opts: as.map(a => ({ value: a.subjectId, label: label(a) })) };
}
const classStudents = async as => { const m = new Map(); for (const a of as) (await listByClass(a.departmentId, a.semester, a.section)).forEach(s => m.set(s.id, s)); return [...m.values()]; };
const sel = (name, label, options) => ({ name, label, type: 'select', options });

export const routes = {
  '/teacher': page('/teacher', async (el, uid, c) => { const rows = await classStudents(c.as);
    await crudView(el, { title: 'Assigned students', csvName: 'students.csv', load: async () => rows,
      cols: [{ key: 'registerNo', label: 'Register no.' }, { key: 'displayName', label: 'Name' }, { key: 'semester', label: 'Sem' }, { key: 'section', label: 'Section' }, { key: 'email', label: 'Email' }] }); }),

  '/teacher/attendance': page('/teacher/attendance', async (el, uid, c) => {
    el.innerHTML = `<h1 class="mb-4 text-xl font-semibold text-indigo-950">Mark attendance</h1>
      <div class="mb-4 flex flex-wrap items-end gap-3"><label class="text-xs font-medium text-slate-600">Class<select id="sub" class="mt-1 block rounded-md border border-slate-300 px-2 py-1.5 text-sm"><option value="">Select</option>${c.opts.map(o => `<option value="${esc(o.value)}">${esc(o.label)}</option>`).join('')}</select></label>
      <label class="text-xs font-medium text-slate-600">Date<input id="date" type="date" max="${today()}" value="${today()}" class="mt-1 block rounded-md border border-slate-300 px-2 py-1.5 text-sm"/></label>
      <button id="load" class="rounded-md bg-indigo-800 px-4 py-2 text-sm font-medium text-white">Load class</button></div><div id="roll"></div>`;
    const roll = el.querySelector('#roll');
    el.querySelector('#load').onclick = async () => {
      const sub = el.querySelector('#sub').value, date = el.querySelector('#date').value, a = c.find(sub);
      if (!a) return toast('Select a class first.', 'error'); if (!date || date > today()) return toast('Pick today or an earlier date.', 'error');
      const [students, done] = await Promise.all([listByClass(a.departmentId, a.semester, a.section), forClassDate(sub, date, uid)]);
      const prev = Object.fromEntries(done.map(r => [r.studentUid, r.status]));
      if (!students.length) { roll.innerHTML = '<p class="text-sm text-slate-500">No students in this class yet.</p>'; return; }
      roll.innerHTML = `<div class="overflow-x-auto rounded-xl border border-slate-200 bg-white"><table class="min-w-full text-sm"><thead class="bg-stone-50 text-left text-xs text-slate-500"><tr><th class="px-3 py-2">Register no.</th><th class="px-3 py-2">Name</th><th class="px-3 py-2">Present</th><th class="px-3 py-2">Absent</th></tr></thead><tbody>
        ${students.map(s => `<tr class="border-t border-slate-100"><td class="px-3 py-2">${esc(s.registerNo)}</td><td class="px-3 py-2">${esc(s.displayName)}</td>
        <td class="px-3 py-2"><input type="radio" name="s_${esc(s.id)}" value="present" ${prev[s.id] !== 'absent' ? 'checked' : ''}/></td><td class="px-3 py-2"><input type="radio" name="s_${esc(s.id)}" value="absent" ${prev[s.id] === 'absent' ? 'checked' : ''}/></td></tr>`).join('')}</tbody></table></div>
        <div class="mt-3 flex gap-3"><button id="save" class="rounded-md bg-indigo-800 px-4 py-2 text-sm font-medium text-white">Save attendance</button><button id="csv" class="text-sm text-indigo-700 underline">Export CSV</button></div>`;
      const read = () => students.map(s => ({ studentUid: s.id, status: roll.querySelector(`[name="s_${s.id}"]:checked`).value }));
      roll.querySelector('#save').onclick = async () => { try { await markAttendance(uid, sub, date, read()); toast('Attendance saved'); } catch (e) { toast(e.message, 'error'); } };
      roll.querySelector('#csv').onclick = () => { const st = Object.fromEntries(read().map(r => [r.studentUid, r.status]));
        downloadCsv(`attendance-${date}.csv`, [{ key: 'registerNo', label: 'Register no.' }, { key: 'displayName', label: 'Name' }, { key: 'date', label: 'Date' }, { key: 'status', label: 'Status' }],
          students.map(s => ({ ...s, date, status: st[s.id] }))); };
    };
  }),

  '/teacher/timetable': page('/teacher/timetable', (el, uid, c) => crudView(el, { title: 'Timetable', csvName: 'timetable.csv',
    fields: [sel('subjectId', 'Class', c.opts), sel('day', 'Day', DAYS), { name: 'startTime', label: 'Start', type: 'time' }, { name: 'endTime', label: 'End', type: 'time' }, { name: 'room', label: 'Room' }, { name: 'published', label: 'Published', type: 'checkbox' }],
    load: () => timetable.listMine(uid), save: v => timetable.create(uid, c.find(v.subjectId), v), remove: r => timetable.remove('timetables', r.id),
    cols: [{ key: 'day', label: 'Day' }, { key: 'startTime', label: 'From' }, { key: 'endTime', label: 'To' }, { key: 'subjectId', label: 'Subject', fmt: v => c.by[v]?.code || v }, { key: 'room', label: 'Room' }, { key: 'published', label: 'Published', fmt: v => v ? 'Yes' : 'No' }] })),

  '/teacher/exams': page('/teacher/exams', (el, uid, c) => crudView(el, { title: 'Exam schedule', csvName: 'exams.csv',
    fields: [sel('subjectId', 'Class', c.opts), { name: 'examDate', label: 'Date', type: 'date' }, { name: 'startTime', label: 'Start', type: 'time' }, { name: 'endTime', label: 'End', type: 'time' }, { name: 'room', label: 'Room' }, { name: 'published', label: 'Published', type: 'checkbox' }],
    load: () => exams.listMine(uid), save: v => exams.create(uid, c.find(v.subjectId), v), remove: r => exams.remove('examinations', r.id),
    cols: [{ key: 'examDate', label: 'Date' }, { key: 'startTime', label: 'From' }, { key: 'endTime', label: 'To' }, { key: 'subjectId', label: 'Subject', fmt: v => c.by[v]?.code || v }, { key: 'room', label: 'Room' }, { key: 'published', label: 'Published', fmt: v => v ? 'Yes' : 'No' }] })),

  '/teacher/results': page('/teacher/results', async (el, uid, c) => { const [studs, exs] = [await classStudents(c.as), await exams.listMine(uid)]; const sn = Object.fromEntries(studs.map(s => [s.id, s]));
    await crudView(el, { title: 'Results', csvName: 'results.csv',
      fields: [sel('studentUid', 'Student', studs.map(s => ({ value: s.id, label: `${s.registerNo} ${s.displayName}` }))), sel('examId', 'Exam', exs.map(e => ({ value: e.id, label: `${e.examDate} ${c.by[e.subjectId]?.code || ''}` }))),
        { name: 'marks', label: 'Marks', type: 'number' }, { name: 'maxMarks', label: 'Max marks', type: 'number' }, { name: 'published', label: 'Published', type: 'checkbox' }],
      load: () => results.listByTeacher(uid),
      save: v => { const e = exs.find(x => x.id === v.examId); return results.upsert(uid, { ...v, subjectId: e.subjectId }); }, remove: r => results.remove('results', r.id),
      cols: [{ key: 'studentUid', label: 'Student', fmt: v => sn[v]?.registerNo || v }, { key: 'subjectId', label: 'Subject', fmt: v => c.by[v]?.code || v }, { key: 'marks', label: 'Marks' }, { key: 'maxMarks', label: 'Out of' }, { key: 'grade', label: 'Grade' }, { key: 'published', label: 'Published', fmt: v => v ? 'Yes' : 'No' }] }); }),

  '/teacher/materials': page('/teacher/materials', (el, uid, c) => crudView(el, { title: 'Study materials',
    fields: [{ name: 'title', label: 'Title' }, sel('subjectId', 'Class', c.opts), { name: 'downloadURL', label: 'Link (https://...)' }, { name: 'published', label: 'Published', type: 'checkbox' }],
    load: () => materials.listMine(uid), save: v => materials.create(uid, c.find(v.subjectId), v), remove: r => materials.remove('studyMaterials', r.id),
    cols: [{ key: 'title', label: 'Title' }, { key: 'subjectId', label: 'Subject', fmt: v => c.by[v]?.code || v }, { key: 'published', label: 'Published', fmt: v => v ? 'Yes' : 'No' },
      { label: 'Link', html: r => `<a href="${esc(r.downloadURL)}" target="_blank" rel="noopener" class="text-indigo-700 underline">Open</a>` }] })),

  '/teacher/events': page('/teacher/events', (el, uid) => crudView(el, { title: 'Events', csvName: 'events.csv',
    fields: [{ name: 'title', label: 'Title' }, { name: 'description', label: 'Description', type: 'textarea' }, { name: 'venue', label: 'Venue' }, { name: 'eventDate', label: 'Date', type: 'date' }, { name: 'published', label: 'Published', type: 'checkbox' }],
    load: () => events.listMine(uid), save: v => events.create(uid, v), remove: r => events.remove('events', r.id),
    cols: [{ key: 'eventDate', label: 'Date' }, { key: 'title', label: 'Title' }, { key: 'venue', label: 'Venue' }, { key: 'published', label: 'Published', fmt: v => v ? 'Yes' : 'No' }] })),
};

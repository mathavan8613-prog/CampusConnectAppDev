import './styles/input.css';
import { Capacitor } from '@capacitor/core';
import { initializeNativeShell } from './native/capacitor.js';
import { onAuthStateChanged } from 'firebase/auth';
import { auth } from './config/firebase.js';
import { setSession, clearState } from './app/state.js';
import { register, start, navigate } from './app/router.js';
import { loadSession } from './services/auth.service.js';
import { updateToast } from './components/toast.js';
import { routes as welcome } from './pages/welcome/welcome.js';
import { routes as authPages } from './pages/auth/auth.js';
import { routes as student } from './pages/student/student.js';
import { routes as teacher } from './pages/teacher/teacher.js';
import { routes as admin } from './pages/admin/admin.js';

for (const set of [welcome, authPages, student, teacher, admin])
  for (const [path, r] of Object.entries(set)) register(path, r.role, r.mount, !!r.pending);

let started = false;
onAuthStateChanged(auth, async user => {
  try { if (user) setSession(user, await loadSession(user)); else clearState(); }
  catch (e) { console.error(e); clearState(); }
  if (!started) { started = true; start(); } else navigate();
});

// Offline banner
const banner = document.getElementById('offline-banner');
const sync = () => banner.classList.toggle('hidden', navigator.onLine);
addEventListener('online', sync); addEventListener('offline', sync); sync();

// Service worker + update flow
if (!Capacitor.isNativePlatform() && 'serviceWorker' in navigator && import.meta.env.PROD) {
  const hadController = !!navigator.serviceWorker.controller; let reloading = false;
  addEventListener('load', async () => {
    const reg = await navigator.serviceWorker.register('/sw.js');
    reg.addEventListener('updatefound', () => { const w = reg.installing;
      w?.addEventListener('statechange', () => { if (w.state === 'installed' && navigator.serviceWorker.controller) updateToast(() => w.postMessage('SKIP_WAITING')); }); });
  });
  navigator.serviceWorker.addEventListener('controllerchange', () => { if (hadController && !reloading) { reloading = true; location.reload(); } });
}

// Capacitor integrations are enabled only inside the Android WebView.
initializeNativeShell().catch(error => console.error('Native shell initialization failed:', error));

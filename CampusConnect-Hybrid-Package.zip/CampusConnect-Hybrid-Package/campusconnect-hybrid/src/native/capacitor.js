/** Native-only integrations. The PWA remains usable in a normal browser. */
import { Capacitor } from '@capacitor/core';

export async function initializeNativeShell() {
  if (!Capacitor.isNativePlatform()) return;

  const [{ App }, { Network }, { StatusBar, Style }, { SplashScreen }] = await Promise.all([
    import('@capacitor/app'),
    import('@capacitor/network'),
    import('@capacitor/status-bar'),
    import('@capacitor/splash-screen')
  ]);

  try {
    await StatusBar.setStyle({ style: Style.Light });
    await StatusBar.setBackgroundColor({ color: '#3730a3' });
  } catch (error) { console.warn('Status bar setup skipped:', error); }

  const banner = document.getElementById('offline-banner');
  const applyNetwork = status => {
    if (banner) {
      banner.classList.toggle('hidden', status.connected);
      banner.textContent = status.connected
        ? ''
        : 'You are offline. Sign-in and live Firebase updates need a connection.';
    }
    document.documentElement.dataset.network = status.connected ? 'online' : 'offline';
  };
  try {
    applyNetwork(await Network.getStatus());
    await Network.addListener('networkStatusChange', applyNetwork);
  } catch (error) { console.warn('Network listener unavailable:', error); }

  // Android hardware back: return through app routes before allowing app exit.
  await App.addListener('backButton', ({ canGoBack }) => {
    if (location.hash && location.hash !== '#/' && location.hash !== '#') {
      history.back();
    } else if (canGoBack) {
      history.back();
    } else {
      App.exitApp();
    }
  });

  try { await SplashScreen.hide(); } catch (error) { /* splash may already be hidden */ }
}

export async function registerNativePushNotifications() {
  if (!Capacitor.isNativePlatform()) return { enabled: false, reason: 'web' };
  const { PushNotifications } = await import('@capacitor/push-notifications');
  let permission = await PushNotifications.checkPermissions();
  if (permission.receive !== 'granted') permission = await PushNotifications.requestPermissions();
  if (permission.receive !== 'granted') return { enabled: false, reason: 'permission-denied' };

  await PushNotifications.register();
  return new Promise(resolve => {
    let settled = false;
    const finish = value => { if (!settled) { settled = true; resolve(value); } };
    PushNotifications.addListener('registration', token => finish({ enabled: true, token: token.value }));
    PushNotifications.addListener('registrationError', error => finish({ enabled: false, error }));
    // Avoid leaving callers waiting indefinitely if the device has no FCM setup.
    setTimeout(() => finish({ enabled: false, reason: 'registration-pending' }), 10000);
  });
}

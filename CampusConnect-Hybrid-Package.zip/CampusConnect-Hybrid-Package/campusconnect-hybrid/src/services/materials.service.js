import { list, add, remove, where } from './base.js';
export const publishedFor = p => list('studyMaterials', where('published', '==', true), where('departmentId', '==', p.departmentId), where('semester', '==', p.semester));
export const listMine = uid => list('studyMaterials', where('createdBy', '==', uid));
// Materials are stored as links (Google Drive, YouTube, etc.), so Firebase Storage is not needed.
export const create = (uid, a, v) => {
  if (!/^https:\/\/\S+$/.test(v.downloadURL)) throw new Error('Link must start with https://');
  return add('studyMaterials', { title: v.title, subjectId: v.subjectId, departmentId: a.departmentId, semester: a.semester,
    downloadURL: v.downloadURL, uploadedBy: uid, createdBy: uid, published: !!v.published });
};
export { remove };

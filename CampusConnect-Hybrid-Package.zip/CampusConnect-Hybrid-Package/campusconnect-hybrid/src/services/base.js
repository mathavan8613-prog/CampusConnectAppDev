import { db } from '../config/firebase.js';
import { collection, doc, getDoc, getDocs, setDoc, addDoc, deleteDoc, query, where, serverTimestamp } from 'firebase/firestore';
export { where };
export const list = async (name, ...c) => (await getDocs(query(collection(db, name), ...c))).docs.map(d => ({ id: d.id, ...d.data() }));
export const get = async (name, id) => { const s = await getDoc(doc(db, name, id)); return s.exists() ? { id: s.id, ...s.data() } : null; };
export const save = (name, id, data) => setDoc(doc(db, name, id), { ...data, updatedAt: serverTimestamp() }, { merge: true });
export const add = (name, data) => addDoc(collection(db, name), { ...data, createdAt: serverTimestamp() });
export const remove = (name, id) => deleteDoc(doc(db, name, id));
export const subjectMap = async () => Object.fromEntries((await list('subjects')).map(s => [s.id, s]));

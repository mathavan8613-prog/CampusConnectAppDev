import { ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { storage } from '../config/firebase.js';

const MAX_BYTES = 20 * 1024 * 1024;
const ALLOWED_TYPES = new Set([
  'application/pdf',
  'image/jpeg',
  'image/png',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation'
]);

export async function uploadStudyMaterial(file, { departmentId, subjectId, uploaderUid }) {
  if (!file) throw new Error('Choose a file to upload.');
  if (!ALLOWED_TYPES.has(file.type)) throw new Error('Unsupported file type. Upload PDF, JPG, PNG, DOCX or PPTX.');
  if (file.size > MAX_BYTES) throw new Error('File size must be 20 MB or less.');
  if (!departmentId || !subjectId || !uploaderUid) throw new Error('Missing upload metadata.');

  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
  const path = `studyMaterials/${departmentId}/${subjectId}/${uploaderUid}/${Date.now()}_${safeName}`;
  const objectRef = ref(storage, path);
  await uploadBytes(objectRef, file, { contentType: file.type, customMetadata: { uploaderUid } });
  return { path, name: file.name, size: file.size, contentType: file.type, url: await getDownloadURL(objectRef) };
}

export async function deleteStudyMaterial(path) {
  if (!path || !path.startsWith('studyMaterials/')) throw new Error('Invalid material path.');
  return deleteObject(ref(storage, path));
}

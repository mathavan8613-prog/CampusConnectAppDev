import { list, add, remove, where } from './base.js';
import { DAYS } from '../utils/date-time.js';
const sort = r => r.sort((a, b) => DAYS.indexOf(a.day) - DAYS.indexOf(b.day) || a.startTime.localeCompare(b.startTime));
export const publishedFor = async p => sort(await list('timetables', where('published', '==', true),
  where('departmentId', '==', p.departmentId), where('semester', '==', p.semester), where('section', '==', p.section)));
export const listMine = async uid => sort(await list('timetables', where('createdBy', '==', uid)));
export const create = (uid, a, v) => {
  if (v.endTime <= v.startTime) throw new Error('End time must be after start time.');
  return add('timetables', { subjectId: v.subjectId, departmentId: a.departmentId, semester: a.semester, section: a.section,
    teacherUid: uid, createdBy: uid, day: v.day, startTime: v.startTime, endTime: v.endTime, room: v.room, published: !!v.published });
};
export { remove };

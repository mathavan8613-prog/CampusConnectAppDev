import { get, save, list, where } from './base.js';
export const getProfile = uid => get('students', uid);
export const updateContact = (uid, { phone, photoURL }) => save('students', uid, { phone, photoURL });
export const listByClass = (d, sem, sec) => list('students', where('departmentId', '==', d), where('semester', '==', Number(sem)), where('section', '==', sec));
export const listByDepartment = d => list('students', where('departmentId', '==', d));

import { list, save, remove, where } from './base.js';
import { gradeFor } from '../utils/date-time.js';
export const mine = uid => list('results', where('studentUid', '==', uid), where('published', '==', true));
export const listByTeacher = uid => list('results', where('createdBy', '==', uid));
export const upsert = (uid, v) => {
  if (v.marks < 0 || v.maxMarks <= 0 || v.marks > v.maxMarks) throw new Error('Marks must be between 0 and the maximum marks.');
  // Deterministic ID prevents duplicate results for the same student and exam.
  return save('results', `${v.studentUid}_${v.examId}`, { studentUid: v.studentUid, subjectId: v.subjectId, examId: v.examId,
    marks: v.marks, maxMarks: v.maxMarks, grade: gradeFor(v.marks / v.maxMarks * 100), published: !!v.published, createdBy: uid });
};
export { remove };

import { list, where } from './base.js';
export const mine = uid => list('notifications', where('recipientUid', '==', uid));

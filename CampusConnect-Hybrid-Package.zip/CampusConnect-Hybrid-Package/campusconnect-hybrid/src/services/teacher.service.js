import { doc, writeBatch, serverTimestamp } from 'firebase/firestore';
import { db } from '../config/firebase.js';
import { get, list, where } from './base.js';
export const getProfile = uid => get('teachers', uid);
export const myAssignments = uid => list('teacherAssignments', where('teacherUid', '==', uid));
export const pendingTeachers = () => list('teachers', where('approvalStatus', '==', 'pending'));
export const approvedTeachers = () => list('teachers', where('approvalStatus', '==', 'approved'));
/** Admin-only (enforced by Firestore rules via the admin custom claim). */
export async function setApproval(uid, approved) {
  const b = writeBatch(db);
  b.update(doc(db, 'users', uid), { status: approved ? 'active' : 'rejected' });
  b.update(doc(db, 'teachers', uid), { approvalStatus: approved ? 'approved' : 'rejected', updatedAt: serverTimestamp() });
  await b.commit();
}

import { createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, sendPasswordResetEmail, updateProfile } from 'firebase/auth';
import { doc, writeBatch, serverTimestamp } from 'firebase/firestore';
import { auth, db } from '../config/firebase.js';
import { get } from './base.js';
import { state, setSession, clearState } from '../app/state.js';

/** Role comes from the server-side users doc or the admin custom claim, never from the browser form. */
export async function loadSession(user) {
  const t = await user.getIdTokenResult(true);
  if (t.claims.admin) return { role: 'admin', status: 'active' };
  const u = await get('users', user.uid);
  return { role: u?.role || null, status: u?.status || null };
}
export const refreshSession = async () => setSession(auth.currentUser, await loadSession(auth.currentUser));

async function signUp(f, role, status, extraCol, extra) {
  state.registering = true;
  try {
    const { user } = await createUserWithEmailAndPassword(auth, f.email, f.password);
    await updateProfile(user, { displayName: f.displayName });
    const b = writeBatch(db);
    b.set(doc(db, 'users', user.uid), { uid: user.uid, role, displayName: f.displayName, email: f.email, status, createdAt: serverTimestamp() });
    b.set(doc(db, extraCol, user.uid), { displayName: f.displayName, email: f.email, ...extra, photoURL: '', createdAt: serverTimestamp() });
    await b.commit();
    await refreshSession();
  } finally { state.registering = false; }
}
export const registerStudent = f => signUp(f, 'student', 'active', 'students', {
  registerNo: f.registerNo, departmentId: f.departmentId, degree: f.degree, year: Number(f.year), semester: Number(f.semester), section: f.section, phone: f.phone || '' });
export const registerTeacher = f => signUp(f, 'teacher', 'pending', 'teachers', {
  facultyId: f.facultyId, departmentId: f.departmentId, designation: f.designation, approvalStatus: 'pending' });
export const login = (email, pw) => signInWithEmailAndPassword(auth, email, pw);
export const resetPassword = email => sendPasswordResetEmail(auth, email);
export async function logout() { await signOut(auth); clearState(); document.getElementById('app').innerHTML = ''; location.hash = '#/login'; }

import { doc, writeBatch, serverTimestamp } from 'firebase/firestore';
import { db } from '../config/firebase.js';
import { list, where } from './base.js';
// Deterministic ID => one record per student/subject/date; re-marking overwrites instead of duplicating.
export const attendanceId = (s, sub, d) => `${s}_${sub}_${d}`;
export async function markAttendance(teacherUid, subjectId, classDate, records) {
  const b = writeBatch(db);
  records.forEach(r => b.set(doc(db, 'attendance', attendanceId(r.studentUid, subjectId, classDate)),
    { studentUid: r.studentUid, subjectId, teacherUid, classDate, status: r.status, markedAt: serverTimestamp() }));
  await b.commit();
}
export const forStudent = uid => list('attendance', where('studentUid', '==', uid));
export const forClassDate = (subjectId, classDate, teacherUid) =>
  list('attendance', where('subjectId', '==', subjectId), where('classDate', '==', classDate), where('teacherUid', '==', teacherUid));

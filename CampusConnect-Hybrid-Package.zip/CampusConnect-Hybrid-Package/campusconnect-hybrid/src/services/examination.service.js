import { list, add, remove, where } from './base.js';
const sort = r => r.sort((a, b) => a.examDate.localeCompare(b.examDate));
export const publishedFor = async p => sort(await list('examinations', where('published', '==', true),
  where('departmentId', '==', p.departmentId), where('semester', '==', p.semester)));
export const listMine = async uid => sort(await list('examinations', where('createdBy', '==', uid)));
export const create = (uid, a, v) => {
  if (v.endTime <= v.startTime) throw new Error('End time must be after start time.');
  return add('examinations', { subjectId: v.subjectId, departmentId: a.departmentId, semester: a.semester,
    examDate: v.examDate, startTime: v.startTime, endTime: v.endTime, room: v.room, published: !!v.published, createdBy: uid });
};
export { remove };

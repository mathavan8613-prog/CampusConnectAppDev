import { esc } from '../utils/validators.js';
export const sidebar = (items, active) => `<aside class="shrink-0 border-b border-slate-200 bg-white md:w-56 md:border-b-0 md:border-r">
  <div class="px-4 py-3 text-lg font-semibold text-indigo-900">CampusConnect</div>
  <nav class="flex gap-1 overflow-x-auto px-2 pb-2 md:flex-col" aria-label="Main">${items.map(i =>
    `<a href="#${i.path}" class="whitespace-nowrap rounded-md px-3 py-2 text-sm ${i.path === active ? 'bg-indigo-50 font-medium text-indigo-900' : 'text-slate-600 hover:bg-slate-100'}">${esc(i.label)}</a>`).join('')}</nav></aside>`;

export function toast(msg, type = 'info') {
  const t = document.createElement('div');
  t.setAttribute('role', 'status');
  t.className = `fixed bottom-4 right-4 z-50 max-w-xs rounded-lg px-4 py-2 text-sm text-white shadow-lg ${type === 'error' ? 'bg-red-600' : 'bg-indigo-800'}`;
  t.textContent = msg; document.body.append(t);
  setTimeout(() => t.remove(), 4000);
}
export function updateToast(onRefresh) {
  const t = document.createElement('div');
  t.className = 'fixed bottom-4 left-4 z-50 flex items-center gap-3 rounded-lg bg-slate-900 px-4 py-2 text-sm text-white shadow-lg';
  t.innerHTML = '<span>A new version is ready.</span><button class="underline">Refresh</button>';
  t.querySelector('button').onclick = onRefresh; document.body.append(t);
}

import { state } from '../app/state.js';
import { esc } from '../utils/validators.js';
export const navbar = () => `<header class="flex items-center justify-between border-b border-slate-200 bg-white px-4 py-3">
  <span class="text-sm text-slate-600">${esc(state.user?.displayName || state.user?.email || '')} (${esc(state.role)})</span>
  <button id="logout" class="text-sm font-medium text-indigo-700 hover:underline">Log out</button></header>`;

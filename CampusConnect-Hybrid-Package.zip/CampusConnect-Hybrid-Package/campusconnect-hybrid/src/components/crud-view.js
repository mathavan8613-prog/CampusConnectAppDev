import { dataTable } from './data-table.js';
import { confirmModal } from './modal.js';
import { toast } from './toast.js';
import { esc } from '../utils/validators.js';
import { downloadCsv } from '../utils/csv-export.js';

const BASE = 'mt-1 w-full rounded-md border border-slate-300 bg-white px-2 py-1.5 text-sm';
function input(f, o) {
  const n = `name="${f.name}"`;
  if (f.type === 'select') return `<select ${n} class="${BASE}"><option value="">Select</option>${o.map(x => {
    const v = typeof x === 'object' ? x.value : x, l = typeof x === 'object' ? x.label : x;
    return `<option value="${esc(v)}">${esc(l)}</option>`; }).join('')}</select>`;
  if (f.type === 'checkbox') return `<input ${n} type="checkbox" class="mt-2 block h-4 w-4"/>`;
  if (f.type === 'textarea') return `<textarea ${n} rows="2" class="${BASE}"></textarea>`;
  return `<input ${n} type="${f.type || 'text'}" ${f.accept ? `accept="${f.accept}"` : ''} ${f.type === 'number' ? 'step="any" min="0"' : ''} class="${BASE}"/>`;
}

/** Config-driven list + form + row actions + CSV export. Every write goes through cfg.save/cfg.remove (service modules). */
export async function crudView(el, cfg) {
  const { title, fields = [], cols, load, save, remove, actions = [], summary, csvName = 'export.csv' } = cfg;
  const opts = {};
  for (const f of fields) if (f.type === 'select') opts[f.name] = typeof f.options === 'function' ? await f.options() : f.options || [];
  async function render() {
    let rows = [];
    try { rows = await load(); } catch (e) { toast(e.message, 'error'); }
    el.innerHTML = `<h1 class="mb-4 text-xl font-semibold text-indigo-950">${esc(title)}</h1>${rows.some(r => r._demo) ? '<p class="mb-3 rounded-md bg-amber-50 px-3 py-2 text-sm text-amber-900">Showing sample data. Real records appear here once they are added.</p>' : ''}
      ${summary ? `<p class="mb-3 text-sm text-slate-600">${summary(rows)}</p>` : ''}
      ${fields.length ? `<form id="cv-form" class="mb-6 grid gap-3 rounded-xl border border-slate-200 bg-white p-4 sm:grid-cols-2 lg:grid-cols-3">
        ${fields.map(f => `<label class="text-xs font-medium text-slate-600">${esc(f.label)}${input(f, opts[f.name] || [])}</label>`).join('')}
        <div class="flex items-end"><button class="rounded-md bg-indigo-800 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-900">Save</button></div></form>` : ''}
      ${rows.length ? '<div class="mb-2 flex justify-end"><button id="cv-csv" class="text-sm text-indigo-700 underline">Export CSV</button></div>' : ''}
      <div class="overflow-x-auto rounded-xl border border-slate-200 bg-white">${dataTable(cols, rows, { remove: !!remove, actions })}</div>`;
    const form = el.querySelector('#cv-form');
    if (form) form.onsubmit = async e => {
      e.preventDefault();
      const v = {};
      for (const f of fields) {
        const c = form.elements[f.name];
        v[f.name] = f.type === 'checkbox' ? c.checked : f.type === 'file' ? c.files[0] : f.type === 'number' ? (c.value === '' ? null : Number(c.value)) : c.value.trim();
        if (f.type !== 'checkbox' && !f.optional && (v[f.name] == null || v[f.name] === '')) return toast(`${f.label} is required`, 'error');
      }
      try { await save(v); toast('Saved'); await render(); } catch (err) { toast(err.message, 'error'); }
    };
    el.querySelector('#cv-csv')?.addEventListener('click', () => downloadCsv(csvName, cols.filter(c => !c.html), rows));
    el.querySelectorAll('[data-del]').forEach(b => b.onclick = async () => {
      if (!await confirmModal('Delete this record? This cannot be undone.')) return;
      try { await remove(rows.find(r => r.id === b.dataset.del)); toast('Deleted'); await render(); } catch (err) { toast(err.message, 'error'); }
    });
    el.querySelectorAll('[data-act]').forEach(b => b.onclick = async () => {
      try { const row = rows.find(r => r.id === b.dataset.id); if (row._demo) return toast('This is sample data, so actions are disabled.', 'error'); await actions[+b.dataset.act].fn(row); toast('Done'); await render(); } catch (err) { toast(err.message, 'error'); }
    });
  }
  await render();
}

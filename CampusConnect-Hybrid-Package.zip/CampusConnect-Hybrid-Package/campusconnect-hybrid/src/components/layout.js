import { navbar } from './navbar.js';
import { sidebar } from './sidebar.js';
import { logout } from '../services/auth.service.js';
export function layout(app, items, active) {
  app.innerHTML = `<div class="min-h-screen md:flex">${sidebar(items, active)}<div class="min-w-0 flex-1">${navbar()}<main id="content" class="p-4 md:p-6"></main></div></div>`;
  app.querySelector('#logout').onclick = logout;
  return app.querySelector('#content');
}

export function confirmModal(msg) {
  return new Promise(res => {
    const o = document.createElement('div');
    o.className = 'fixed inset-0 z-50 flex items-center justify-center bg-black/40';
    o.innerHTML = `<div role="dialog" aria-modal="true" class="w-80 rounded-xl bg-white p-5 shadow-xl"><p class="mb-4 text-sm"></p>
      <div class="flex justify-end gap-2"><button data-v="0" class="rounded-md px-3 py-1.5 text-sm">Cancel</button>
      <button data-v="1" class="rounded-md bg-red-600 px-3 py-1.5 text-sm text-white">Delete</button></div></div>`;
    o.querySelector('p').textContent = msg;
    o.onclick = e => { const v = e.target.dataset?.v; if (v !== undefined) { o.remove(); res(v === '1'); } };
    document.body.append(o);
  });
}

import { esc } from '../utils/validators.js';
export function dataTable(cols, rows, { remove = false, actions = [] } = {}) {
  if (!rows.length) return '<p class="p-6 text-center text-sm text-slate-500">No records yet.</p>';
  const th = 'px-3 py-2 text-left text-xs font-semibold text-slate-500';
  const hasAct = remove || actions.length;
  return `<table class="min-w-full divide-y divide-slate-200 text-sm"><thead class="bg-stone-50"><tr><th class="${th}">#</th>
    ${cols.map(c => `<th class="${th}">${esc(c.label)}</th>`).join('')}${hasAct ? `<th class="${th}">Actions</th>` : ''}</tr></thead>
    <tbody class="divide-y divide-slate-100">${rows.map((r, i) => `<tr><td class="px-3 py-2 text-slate-400">${i + 1}</td>${cols.map(c => `<td class="px-3 py-2">${c.html ? c.html(r) : esc(c.fmt ? c.fmt(r[c.key], r) : r[c.key])}</td>`).join('')}
    ${hasAct ? `<td class="space-x-3 px-3 py-2">${actions.map((a, i) => `<button data-act="${i}" data-id="${esc(r.id)}" class="text-indigo-700 underline">${esc(a.label)}</button>`).join('')}${remove ? `<button data-del="${esc(r.id)}" class="text-red-600 underline">Delete</button>` : ''}</td>` : ''}</tr>`).join('')}</tbody></table>`;
}

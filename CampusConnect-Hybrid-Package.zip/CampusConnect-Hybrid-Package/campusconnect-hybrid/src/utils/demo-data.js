// Built-in sample records (10 per section) shown in the student portal when Firestore has no real records yet.
import { gradeFor } from './date-time.js';
const d = n => { const x = new Date(); x.setDate(x.getDate() + n); return new Date(x.getTime() - x.getTimezoneOffset() * 6e4).toISOString().slice(0, 10); };
const SUBJECTS = [['DBMS', 'Database Management System'], ['CN', 'Computer Networks'], ['JAVA', 'Java Programming'], ['PCD', 'Principles of Compiler Design'],
  ['PMCS', 'Principles of Modern Communication Systems'], ['OS', 'Operating Systems'], ['DS', 'Data Structures'], ['SE', 'Software Engineering'],
  ['ML', 'Machine Learning'], ['WT', 'Web Technology']];
export const SUBJECT_NAMES = Object.fromEntries(SUBJECTS);
/** "DBMS - Database Management System" for real subjects (map by id) or sample codes. */
export const subjectLabel = (sm, v) => sm?.[v] ? `${sm[v].code} - ${sm[v].name}` : SUBJECT_NAMES[v] ? `${v} - ${SUBJECT_NAMES[v]}` : v;
const code = i => SUBJECTS[i % SUBJECTS.length][0];
const row = (k, i, o) => ({ id: `demo-${k}-${i}`, ...o });
const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
const MARKS = [78, 85, 66, 92, 71, 88, 59, 74, 81, 95];
const EVENTS = [['Hackathon 24h', 'Main Lab', 'Build a campus tool in 24 hours.'], ['Tech talk: Cloud careers', 'Seminar Hall', 'Guest talk by industry mentors.'],
  ['Sports day', 'Ground', 'Inter-department games.'], ['Cultural fest', 'Auditorium', 'Music, dance and drama.'], ['Coding contest', 'Lab 3', 'Solve problems against the clock.'],
  ['Resume workshop', 'Seminar Hall', 'Write a resume that gets shortlisted.'], ['Alumni meet', 'Auditorium', 'Meet and learn from alumni.'], ['Project expo', 'Main Hall', 'Show your mini projects.'],
  ['Blood donation camp', 'Medical Room', 'Organised with the NSS unit.'], ['Quiz night', 'Library Hall', 'Teams of three, general and tech rounds.']];
export const DEMO = {
  subjects: SUBJECTS.map(([c, name], i) => row('sb', i, { code: c, name, departmentId: 'CSE', semester: 5 + (i % 2), credits: i % 3 === 0 ? 4 : 3 })),
  attendance: SUBJECTS.map((_, i) => row('att', i, { subjectId: code(i), classDate: d(-(i + 1)), status: [2, 6].includes(i) ? 'absent' : 'present' })),
  timetable: DAYS.flatMap((day, i) => [row('tt', i * 2, { day, startTime: '09:00', endTime: '09:50', subjectId: code(i * 2), room: `Room ${101 + i}` }),
    row('tt', i * 2 + 1, { day, startTime: '11:00', endTime: '11:50', subjectId: code(i * 2 + 1), room: `Lab ${1 + (i % 3)}` })]),
  exams: SUBJECTS.map((_, i) => row('ex', i, { subjectId: code(i), examDate: d(7 + i * 2), startTime: '10:00', endTime: '13:00', room: `Hall ${1 + (i % 4)}` })),
  results: MARKS.map((marks, i) => row('rs', i, { subjectId: code(i), marks, maxMarks: 100, grade: gradeFor(marks) })),
  materials: SUBJECTS.map((_, i) => row('mt', i, { title: `${code(i)} ${['Unit 1 notes', 'cheat sheet', 'slides', 'lab manual', 'question bank'][i % 5]}`, subjectId: code(i), downloadURL: 'https://example.com/sample-material' })),
  events: EVENTS.map(([title, venue, description], i) => row('ev', i, { title, venue, description, eventDate: d(3 + i * 3), registered: 'No' })),
  notifications: [['Welcome to CampusConnect', 'Your account is ready.'], ['Timetable published', 'Check this week\u2019s classes.'], ['Exam schedule released', 'Internal exams start soon.'], ['Library notice', 'Return borrowed books by Friday.']]
    .map(([title, body], i) => row('nt', i, { title, body, createdAt: `${d(-i)} 09:00` })),
};
/** Real records win; sample rows appear only when there are none (or loading fails). */
export async function orDemo(loader, demo) {
  try { const r = await loader(); if (r.length) return r; } catch (e) { console.warn('Using sample data:', e.message); }
  return demo.map(x => ({ ...x, _demo: true }));
}

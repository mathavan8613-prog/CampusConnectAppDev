export const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const isEmail = v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v || '');
export const isPhone = v => !v || /^[0-9+\-\s]{7,15}$/.test(v);
export const isHttps = v => !v || /^https:\/\/\S+$/.test(v);
export function validateAccount(f) {
  const e = [];
  if (!f.displayName?.trim()) e.push('Name is required.');
  if (!isEmail(f.email)) e.push('Enter a valid email address.');
  if ((f.password || '').length < 8) e.push('Password must be at least 8 characters.');
  return e;
}
export const authError = e => ({
  'auth/invalid-credential': 'Email or password is incorrect.',
  'auth/email-already-in-use': 'That email is already registered. Log in instead.',
  'auth/weak-password': 'Password is too weak. Use at least 8 characters.',
  'auth/too-many-requests': 'Too many attempts. Try again later.',
  'auth/network-request-failed': 'No connection. Check your network and retry.',
}[e.code] || e.message);

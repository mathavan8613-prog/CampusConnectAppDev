const cell = v => {
  let s = v == null ? '' : String(v);
  if (/^[=+@]/.test(s)) s = "'" + s; // block spreadsheet formula injection
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};
export const toCsv = (cols, rows) => [
  cols.map(c => cell(c.label)).join(','),
  ...rows.map(r => cols.map(c => cell(c.fmt ? c.fmt(r[c.key], r) : r[c.key])).join(',')),
].join('\r\n');
export function downloadCsv(name, cols, rows) {
  const blob = new Blob(['\uFEFF' + toCsv(cols, rows)], { type: 'text/csv;charset=utf-8' }); // BOM keeps Unicode names intact in Excel
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

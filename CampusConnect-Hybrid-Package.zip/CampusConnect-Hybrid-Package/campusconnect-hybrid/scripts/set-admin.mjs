// Trusted admin bootstrap. Run locally with GOOGLE_APPLICATION_CREDENTIALS pointing at a service-account key (never commit it).
import admin from 'firebase-admin';
const email = process.argv[2];
if (!email) { console.error('Usage: npm run set-admin -- user@example.com'); process.exit(1); }
admin.initializeApp({ credential: admin.credential.applicationDefault() });
const u = await admin.auth().getUserByEmail(email);
await admin.auth().setCustomUserClaims(u.uid, { admin: true });
console.log(`Admin claim set for ${email}. Sign out and back in to refresh the token.`);

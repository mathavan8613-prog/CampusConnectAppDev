# Android platform setup

The Android project is generated from Capacitor so that Gradle files match the Capacitor version installed by npm. From this folder run:

```bash
npm install
npx cap add android
npm run android:sync
npx cap open android
```

After generation, inspect `android/app/src/main/AndroidManifest.xml`. Capacitor supplies the standard Internet permission. Add only additional permissions required by features you actually enable. For push notifications, configure Firebase for Android and place the downloaded `google-services.json` at `android/app/google-services.json` (never commit private signing keys).

To regenerate web assets after source edits:

```bash
npm run build
npx cap sync android
```

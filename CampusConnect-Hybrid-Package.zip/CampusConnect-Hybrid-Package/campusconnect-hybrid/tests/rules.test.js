import { initializeTestEnvironment, assertFails, assertSucceeds } from '@firebase/rules-unit-testing';
import { readFileSync } from 'node:fs';
import { before, after, test } from 'node:test';
import { doc, setDoc, updateDoc } from 'firebase/firestore';

let env;
before(async () => {
  env = await initializeTestEnvironment({ projectId: 'cc-test', firestore: { rules: readFileSync('firestore.rules', 'utf8') } });
  await env.withSecurityRulesDisabled(async c => { const d = c.firestore();
    await setDoc(doc(d, 'users/s1'), { role: 'student', status: 'active' });
    await setDoc(doc(d, 'users/t1'), { role: 'teacher', status: 'active' });
    await setDoc(doc(d, 'users/t2'), { role: 'teacher', status: 'pending' });
    await setDoc(doc(d, 'teacherAssignments/t1_math'), { teacherUid: 't1', subjectId: 'math' }); });
});
after(() => env.cleanup());
const att = (s, sub, id) => ({ studentUid: s, subjectId: sub, teacherUid: 't1', classDate: '2026-01-05', status: 'present', markedAt: new Date() });
const fs = uid => env.authenticatedContext(uid).firestore();

test('student cannot write attendance', () => assertFails(setDoc(doc(fs('s1'), 'attendance/s1_math_2026-01-05'), att('s1', 'math'))));
test('assigned teacher can mark attendance with the unique-key ID', () => assertSucceeds(setDoc(doc(fs('t1'), 'attendance/s1_math_2026-01-05'), att('s1', 'math'))));
test('teacher cannot mark a subject they are not assigned to', () => assertFails(setDoc(doc(fs('t1'), 'attendance/s1_physics_2026-01-05'), att('s1', 'physics'))));
test('attendance ID must match student/subject/date', () => assertFails(setDoc(doc(fs('t1'), 'attendance/random-id'), att('s1', 'math'))));
test('teacher cannot self-approve', () => assertFails(updateDoc(doc(fs('t2'), 'users/t2'), { status: 'active' })));
test('student cannot change own role', () => assertFails(updateDoc(doc(fs('s1'), 'users/s1'), { role: 'teacher' })));
test('unauthenticated users read nothing', () => assertFails(setDoc(doc(env.unauthenticatedContext().firestore(), 'users/s1'), { role: 'admin' })));

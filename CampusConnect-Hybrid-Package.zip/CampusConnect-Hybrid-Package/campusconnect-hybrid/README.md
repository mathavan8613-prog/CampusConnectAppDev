# CampusConnect PWA (Phase 1)

Vite + vanilla JS + Tailwind v4 + Firebase (Auth, Firestore, Storage). Pages call service modules; only `src/services/*` touch the Firebase SDK.

## Setup
1. `npm install`
2. Firebase Console: create a project, enable **Email/Password** auth, create **Firestore** (Storage is not used), register a Web app.
3. `cp .env.example .env.local` and fill in the web config values (never commit `.env.local`).
4. Deploy rules: `npx firebase login && npx firebase use <project-id> && npx firebase deploy --only firestore:rules,firestore:indexes`
5. `npm run dev`

## First admin (trusted process)
Register normally, then with a service-account key outside the repo:
`GOOGLE_APPLICATION_CREDENTIALS=/path/key.json npm run set-admin -- you@example.com`, then log out and in. The admin portal lets you add departments and subjects, approve teachers and assign teachers to subjects (assignment ID = `teacherUid_subjectId`, which the rules use).

## Rules tests
`npm run test:rules` (needs the Firestore emulator and Java).

## Deploy
`npm run build && npx firebase deploy --only hosting`. Test install and offline with `npm run build && npm run preview` (service worker is production-only).

## Notes
- Use synthetic demo data only. Query design: all filters are equality-only, so no composite indexes are needed yet; add them to `firestore.indexes.json` when you add `orderBy` queries.
- Offline: only the app shell is cached. No student data is ever cached.
- Study materials are saved as https links, so no Firebase Storage or file upload is needed.
- Student pages show built-in sample records when Firestore has no real ones yet (marked with a notice).

Place your approved CampusConnect images in this folder.

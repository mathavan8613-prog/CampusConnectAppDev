Place your approved CampusConnect icons in this folder.

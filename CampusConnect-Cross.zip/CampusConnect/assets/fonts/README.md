Place your approved CampusConnect fonts in this folder.

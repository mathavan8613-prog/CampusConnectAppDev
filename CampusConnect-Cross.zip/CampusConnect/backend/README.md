# Firebase backend notes

CampusConnect Mobile is configured to use the same Firebase project as the existing PWA. The mobile client uses only the Firebase client SDK and the public Firebase Web App configuration values. Never put a service-account JSON file, private key, Admin SDK credential, or private API secret in this folder or in the mobile app.

## Existing PWA rules

The source PWA ZIP contains `firestore.rules`. Those rules are retained in the project root as `firestore.rules.reference` for review. They use the `admin` custom claim for administrator access and read the role/status from `users/{uid}` for student and teacher access. Deploying a rules file is a backend change and must be reviewed against the live database before deployment.

## Storage rules

The existing PWA does not configure Firebase Storage. Before enabling teacher file uploads, deploy Storage Rules that restrict writes to authenticated active teachers/admins and validate the intended folder, file size and content type. Example policy is in `storage.rules.example`; adapt the path and role checks to your actual user records and test in the Firebase Emulator Suite before deployment.

## Trusted operations

Admin custom claims must be granted only by a trusted Admin SDK environment (for example, a secured one-time script or Cloud Function). Never let a mobile client set its own `admin` claim. Teacher approval should be performed by an admin-authorized operation and the corresponding Firestore rules must protect both `users/{uid}` and `teachers/{uid}`.

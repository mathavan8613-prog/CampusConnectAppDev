# Optional multi-section teacher assignment migration

The uploaded PWA currently uses `teacherAssignments/{teacherUid}_{subjectId}`. That supports a teacher's subject assignment but cannot represent two distinct sections of the same subject for the same teacher without overwriting the same document.

The mobile app initially preserves this existing ID convention for compatibility. To support the same subject in multiple classes/sections, migrate to a deterministic class-scoped ID:

`{teacherUid}_{departmentId}_{semester}_{section}_{subjectId}`

Each assignment document should contain:

- `teacherUid`
- `departmentId`
- `semester` (number)
- `section`
- `subjectId`
- `assignedAt`

Before deploying this schema, update the Firestore rules so teacher writes check the exact teacher + department + semester + section + subject assignment, and include class identity in attendance records and validation. Update the PWA and mobile app together. Do not deploy a partial migration: a mismatch between rules and clients can either lock out valid users or expose records.

The current mobile starter intentionally does not silently alter the live Firestore schema or existing PWA rules.

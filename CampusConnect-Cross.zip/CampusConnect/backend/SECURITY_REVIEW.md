# Security review of the uploaded PWA rules

This review is based on `firestore.rules` in the uploaded CampusConnect PWA ZIP.

## Rules already present

- Admin access uses the Firebase Auth custom claim `admin`.
- Student and teacher roles/status are read from `users/{uid}`.
- Students can update only their own `phone` and `photoURL` fields in the student profile.
- Student result reads are restricted to their own published result documents.
- Attendance writes require an assigned subject and the teacher's UID.
- Teacher-managed timetable, exam, result and material writes check the teacher assignment and `createdBy`.

## Changes required before production

1. **Teacher student-directory reads are broader than the UI.** The current rule for `students/{id}` allows an active teacher to read every student in the teacher's department. The app queries assigned class/section students, but a client query is not a security boundary. Tighten the rule to verify a class-specific assignment document for the student's department, semester and section.
2. **Same-subject multi-section assignment limitation.** Current assignment IDs are `teacherUid_subjectId`, so the same teacher cannot have separate assignment documents for the same subject in two sections. Follow `ASSIGNMENT_MIGRATION.md`, then update rules and both clients together.
3. **Storage rules are not present in the PWA ZIP.** The mobile project adds an upload helper, but file upload must remain disabled until reviewed Storage Rules are deployed and tested. `storage.rules.example` denies all access by default intentionally.
4. **Teacher notification scope.** Current Firestore rules allow any active teacher to create notifications. If teachers should notify only their assigned students, enforce that recipient scope in Firestore Rules or a trusted Cloud Function.
5. **Admin actions.** Continue to grant `admin` claims only from a trusted Admin SDK environment. Never expose service-account credentials in the app.

Do not deploy proposed rule changes directly to production without emulator tests and a coordinated PWA/mobile release.

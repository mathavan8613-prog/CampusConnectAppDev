import React from 'react';
import { Text, TextInput, View } from 'react-native';
import { styles } from '../styles/globalStyles';
export default function AppInput({ label, value, onChangeText, placeholder, secureTextEntry, keyboardType, multiline }) {
  return <View><Text style={{ color: '#536078', fontWeight: '600', fontSize: 13 }}>{label}</Text><TextInput style={[styles.input, multiline && { minHeight: 90, textAlignVertical: 'top' }]} value={value} onChangeText={onChangeText} placeholder={placeholder || label} secureTextEntry={secureTextEntry} keyboardType={keyboardType} autoCapitalize={keyboardType === 'email-address' ? 'none' : 'sentences'} multiline={multiline} /></View>;
}

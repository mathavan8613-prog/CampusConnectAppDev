import React from 'react';
import { View, Text } from 'react-native';
import { styles } from '../styles/globalStyles';
export default function RecordCard({ title, subtitle, details }) { return <View style={styles.card}><Text style={styles.cardTitle}>{title || 'Record'}</Text>{subtitle ? <Text style={styles.muted}>{subtitle}</Text> : null}{details ? <Text style={styles.body}>{details}</Text> : null}</View>; }

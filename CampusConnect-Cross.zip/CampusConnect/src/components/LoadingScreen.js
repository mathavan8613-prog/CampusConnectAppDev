import React from 'react';
import { ActivityIndicator, View, Text } from 'react-native';
import { COLORS } from '../styles/colors';
export default function LoadingScreen({ message = 'Loading CampusConnect...' }) { return <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#F5F7FB' }}><ActivityIndicator size="large" color={COLORS.primary} /><Text style={{ marginTop: 12, color: '#718096' }}>{message}</Text></View>; }

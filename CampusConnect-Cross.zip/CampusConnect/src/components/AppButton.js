import React from 'react';
import { Pressable, Text, ActivityIndicator } from 'react-native';
import { styles } from '../styles/globalStyles';
export default function AppButton({ title, onPress, loading, disabled, variant = 'primary' }) {
  return <Pressable onPress={onPress} disabled={disabled || loading} style={[styles.button, variant === 'secondary' && { backgroundColor: '#E9EEFF' }, (disabled || loading) && { opacity: 0.6 }]}>
    {loading ? <ActivityIndicator color={variant === 'secondary' ? '#243B80' : '#fff'} /> : <Text style={[styles.buttonText, variant === 'secondary' && { color: '#243B80' }]}>{title}</Text>}
  </Pressable>;
}

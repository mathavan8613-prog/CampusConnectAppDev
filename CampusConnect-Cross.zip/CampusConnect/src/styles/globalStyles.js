import { StyleSheet } from 'react-native';
import { COLORS } from './colors';
export const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: COLORS.background }, content: { padding: 20, paddingBottom: 36 },
  title: { fontSize: 25, fontWeight: '800', color: COLORS.text }, subtitle: { fontSize: 14, color: COLORS.muted, marginTop: 5 },
  card: { backgroundColor: COLORS.surface, borderRadius: 16, padding: 16, borderWidth: 1, borderColor: COLORS.border, marginBottom: 12 },
  cardTitle: { fontSize: 16, fontWeight: '700', color: COLORS.text }, body: { fontSize: 14, color: COLORS.text, marginTop: 6 }, muted: { color: COLORS.muted, fontSize: 12, marginTop: 5 },
  input: { backgroundColor: '#fff', borderWidth: 1, borderColor: COLORS.border, borderRadius: 11, paddingHorizontal: 13, paddingVertical: 12, fontSize: 15, color: COLORS.text, marginTop: 6, marginBottom: 12 },
  button: { backgroundColor: COLORS.primary, paddingVertical: 13, paddingHorizontal: 16, borderRadius: 11, alignItems: 'center', marginTop: 8 }, buttonText: { color: '#fff', fontWeight: '700', fontSize: 15 },
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
});

import { useCallback, useEffect, useState } from 'react';
export default function useFirestore(loader, dependencies = []) {
 const [data,setData]=useState([]); const [loading,setLoading]=useState(true); const [error,setError]=useState('');
 const refresh=useCallback(async()=>{setLoading(true);setError('');try{setData(await loader());}catch(e){setError(e.message||'Unable to load data');}finally{setLoading(false);}}, dependencies);
 useEffect(()=>{refresh();},[refresh]);
 return {data,loading,error,refresh};
}

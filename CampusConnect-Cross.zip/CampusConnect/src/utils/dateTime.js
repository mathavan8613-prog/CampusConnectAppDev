export const todayISO = () => new Date().toISOString().slice(0,10);
export const formatDate = value => value ? new Date(value).toLocaleDateString() : '—';
export const sortByDate = rows => [...rows].sort((a,b)=>String(a.date||a.examDate||a.classDate||'').localeCompare(String(b.date||b.examDate||b.classDate||'')));

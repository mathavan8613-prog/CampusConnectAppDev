export const titleCase = value => String(value || '').replace(/([A-Z])/g,' $1').replace(/^./,c=>c.toUpperCase());
export const safeError = error => error?.message || 'Something went wrong. Please try again.';

export const ROLES = { STUDENT: 'student', TEACHER: 'teacher', ADMIN: 'admin' };
export const COLLECTIONS = {
  users: 'users', students: 'students', teachers: 'teachers', departments: 'departments',
  subjects: 'subjects', teacherAssignments: 'teacherAssignments', attendance: 'attendance',
  timetables: 'timetables', examinations: 'examinations', results: 'results',
  studyMaterials: 'studyMaterials', events: 'events', eventRegistrations: 'eventRegistrations',
  notifications: 'notifications'
};
export const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

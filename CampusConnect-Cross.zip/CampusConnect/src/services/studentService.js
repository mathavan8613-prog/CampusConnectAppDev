import { getOne, list, save, where } from './firestoreService';
export const getProfile = uid => getOne('students', uid);
export const updateContact = (uid, data) => save('students', uid, { phone: data.phone || '', photoURL: data.photoURL || '' });
export const listByClass = (departmentId, semester, section) => list('students', where('departmentId', '==', departmentId), where('semester', '==', Number(semester)), where('section', '==', section));
export const listByDepartment = departmentId => list('students', where('departmentId', '==', departmentId));

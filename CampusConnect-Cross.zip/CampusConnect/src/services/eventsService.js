import { add, list, remove, save, where } from './firestoreService';
export const published = () => list('events', where('published', '==', true));
export const mine = uid => list('events', where('createdBy', '==', uid));
export const create = (uid, v) => add('events', { title: v.title, description: v.description || '', venue: v.venue || '', eventDate: v.eventDate, published: !!v.published, createdBy: uid });
export const myRegistrations = uid => list('eventRegistrations', where('studentUid', '==', uid));
export const registerFor = (eventId, uid) => save('eventRegistrations', `${eventId}_${uid}`, { eventId, studentUid: uid, status: 'registered' });
export { remove };

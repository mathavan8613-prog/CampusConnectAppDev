import { add, list, remove, where } from './firestoreService';
export const forStudent = p => list('timetables', where('published', '==', true), where('departmentId', '==', p.departmentId), where('semester', '==', Number(p.semester)), where('section', '==', p.section));
export const forTeacher = uid => list('timetables', where('createdBy', '==', uid));
export const create = (uid, assignment, v) => {
  if (v.endTime <= v.startTime) throw new Error('End time must be after start time.');
  return add('timetables', { subjectId: v.subjectId, departmentId: assignment.departmentId, semester: Number(assignment.semester), section: assignment.section, teacherUid: uid, createdBy: uid, day: v.day, startTime: v.startTime, endTime: v.endTime, room: v.room, published: !!v.published });
};
export { remove };

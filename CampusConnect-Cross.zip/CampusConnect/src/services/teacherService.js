import { list, where, ref } from './firestoreService';
import { getDoc, writeBatch, serverTimestamp } from 'firebase/firestore';
import { db } from '../config/firebase';
export const getProfile = uid => getDoc(ref('teachers', uid)).then(s => s.exists() ? { id: s.id, ...s.data() } : null);
export const myAssignments = uid => list('teacherAssignments', where('teacherUid', '==', uid));
export const listStudentsForAssignment = a => list('students', where('departmentId', '==', a.departmentId), where('semester', '==', Number(a.semester)), where('section', '==', a.section));
export const pendingTeachers = () => list('teachers', where('approvalStatus', '==', 'pending'));
export async function setApproval(uid, approved) {
  const batch = writeBatch(db);
  batch.update(ref('users', uid), { status: approved ? 'active' : 'rejected' });
  batch.update(ref('teachers', uid), { approvalStatus: approved ? 'approved' : 'rejected', updatedAt: serverTimestamp() });
  await batch.commit();
}

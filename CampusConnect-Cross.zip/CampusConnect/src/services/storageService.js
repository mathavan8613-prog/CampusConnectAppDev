import * as DocumentPicker from 'expo-document-picker';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { storage } from '../config/firebase';
export async function pickAndUploadMaterial(folder = 'study-materials') {
  const picked = await DocumentPicker.getDocumentAsync({ copyToCacheDirectory: true, multiple: false });
  if (picked.canceled || !picked.assets?.length) return null;
  const file = picked.assets[0];
  const response = await fetch(file.uri);
  const blob = await response.blob();
  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
  const storageRef = ref(storage, `${folder}/${Date.now()}_${safeName}`);
  await uploadBytes(storageRef, blob, { contentType: file.mimeType || 'application/octet-stream' });
  return { name: file.name, downloadURL: await getDownloadURL(storageRef), size: file.size || null };
}

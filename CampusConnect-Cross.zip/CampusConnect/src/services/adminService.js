import { add, list, remove, save, where } from './firestoreService';
export const students = () => list('students');
export const teachers = () => list('teachers');
export const departments = () => list('departments');
export const subjects = () => list('subjects');
export const assignments = () => list('teacherAssignments');
export const createDepartment = data => add('departments', data);
export const createSubject = data => add('subjects', data);
export const createAssignment = (teacherUid, data) => {
  // Current PWA rules use teacherUid_subjectId. Multiple sections for the same subject require the rules migration documented in backend/.
  const id = `${teacherUid}_${data.subjectId}`;
  return save('teacherAssignments', id, { teacherUid, ...data });
};
export const deleteStudent = uid => remove('students', uid);
export const deleteTeacher = uid => remove('teachers', uid);

import { add, list, where, ref } from './firestoreService';
import { updateDoc, serverTimestamp } from 'firebase/firestore';
export const mine = uid => list('notifications', where('recipientUid', '==', uid));
export const send = (uid, recipientUid, title, message) => add('notifications', { recipientUid, title, message, sentBy: uid, readAt: null });
export const markRead = id => updateDoc(ref('notifications', id), { readAt: serverTimestamp() });

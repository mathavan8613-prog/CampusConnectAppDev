import { add, list, remove, where } from './firestoreService';
export const forStudent = p => list('studyMaterials', where('published', '==', true), where('departmentId', '==', p.departmentId), where('semester', '==', Number(p.semester)));
export const forTeacher = uid => list('studyMaterials', where('createdBy', '==', uid));
export const createLink = (uid, assignment, v) => {
  if (!/^https:\/\/\S+$/.test(v.downloadURL)) throw new Error('Please provide a valid HTTPS link.');
  return add('studyMaterials', { title: v.title, subjectId: v.subjectId, departmentId: assignment.departmentId, semester: Number(assignment.semester), downloadURL: v.downloadURL, uploadedBy: uid, createdBy: uid, published: !!v.published });
};
export { remove };

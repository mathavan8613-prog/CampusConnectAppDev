import { doc, serverTimestamp, writeBatch } from 'firebase/firestore';
import { db } from '../config/firebase';
import { list, where } from './firestoreService';
export const attendanceId = (studentUid, subjectId, classDate) => `${studentUid}_${subjectId}_${classDate}`;
export async function markAttendance(teacherUid, subjectId, classDate, records) {
  const batch = writeBatch(db);
  records.forEach(r => batch.set(doc(db, 'attendance', attendanceId(r.studentUid, subjectId, classDate)), {
    studentUid: r.studentUid, subjectId, teacherUid, classDate, status: r.status, markedAt: serverTimestamp()
  }));
  await batch.commit();
}
export const forStudent = uid => list('attendance', where('studentUid', '==', uid));
export const forClassDate = (subjectId, classDate, teacherUid) => list('attendance', where('subjectId', '==', subjectId), where('classDate', '==', classDate), where('teacherUid', '==', teacherUid));

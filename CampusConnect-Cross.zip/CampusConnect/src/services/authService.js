import { createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, sendPasswordResetEmail, updateProfile } from 'firebase/auth';
import { doc, serverTimestamp, writeBatch } from 'firebase/firestore';
import { auth, db } from '../config/firebase';

export const login = (email, password) => signInWithEmailAndPassword(auth, email.trim(), password);
export const logout = () => signOut(auth);
export const resetPassword = email => sendPasswordResetEmail(auth, email.trim());

async function register(form, role, status, collection, extra) {
  const credential = await createUserWithEmailAndPassword(auth, form.email.trim(), form.password);
  await updateProfile(credential.user, { displayName: form.displayName.trim() });
  const batch = writeBatch(db);
  batch.set(doc(db, 'users', credential.user.uid), {
    uid: credential.user.uid, role, displayName: form.displayName.trim(), email: form.email.trim(), status, createdAt: serverTimestamp()
  });
  batch.set(doc(db, collection, credential.user.uid), {
    displayName: form.displayName.trim(), email: form.email.trim(), ...extra, photoURL: '', createdAt: serverTimestamp()
  });
  await batch.commit();
  return credential.user;
}
export const registerStudent = form => register(form, 'student', 'active', 'students', {
  registerNo: form.registerNo, departmentId: form.departmentId, degree: form.degree || '',
  year: Number(form.year), semester: Number(form.semester), section: form.section, phone: form.phone || ''
});
export const registerTeacher = form => register(form, 'teacher', 'pending', 'teachers', {
  facultyId: form.facultyId, departmentId: form.departmentId, designation: form.designation || '', approvalStatus: 'pending'
});

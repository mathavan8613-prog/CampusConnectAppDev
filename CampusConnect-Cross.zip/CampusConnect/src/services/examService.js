import { add, list, remove, where } from './firestoreService';
export const forStudent = p => list('examinations', where('published', '==', true), where('departmentId', '==', p.departmentId), where('semester', '==', Number(p.semester)));
export const forTeacher = uid => list('examinations', where('createdBy', '==', uid));
export const create = (uid, assignment, v) => {
  if (v.endTime <= v.startTime) throw new Error('End time must be after start time.');
  return add('examinations', { subjectId: v.subjectId, departmentId: assignment.departmentId, semester: Number(assignment.semester), examDate: v.examDate, startTime: v.startTime, endTime: v.endTime, room: v.room, published: !!v.published, createdBy: uid });
};
export { remove };

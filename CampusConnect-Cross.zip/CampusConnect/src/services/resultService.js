import { list, save, remove, where } from './firestoreService';
export const forStudent = uid => list('results', where('studentUid', '==', uid), where('published', '==', true));
export const forTeacher = uid => list('results', where('createdBy', '==', uid));
export async function upsert(uid, v) {
  const marks = Number(v.marks), maxMarks = Number(v.maxMarks);
  if (marks < 0 || maxMarks <= 0 || marks > maxMarks) throw new Error('Marks must be between zero and maximum marks.');
  const percent = marks / maxMarks * 100;
  const grade = percent >= 90 ? 'O' : percent >= 80 ? 'A+' : percent >= 70 ? 'A' : percent >= 60 ? 'B+' : percent >= 50 ? 'B' : 'RA';
  return save('results', `${v.studentUid}_${v.examId}`, { studentUid: v.studentUid, subjectId: v.subjectId, examId: v.examId, marks, maxMarks, grade, published: !!v.published, createdBy: uid });
}
export { remove };

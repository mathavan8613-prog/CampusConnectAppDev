import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db } from '../config/firebase';

const AuthContext = createContext(null);
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [accountError, setAccountError] = useState('');

  useEffect(() => onAuthStateChanged(auth, async current => {
    setLoading(true); setAccountError(''); setUser(current);
    if (!current) { setProfile(null); setLoading(false); return; }
    try {
      const token = await current.getIdTokenResult(true);
      const snap = await getDoc(doc(db, 'users', current.uid));
      const data = snap.exists() ? snap.data() : {};
      const role = token.claims.admin === true ? 'admin' : data.role;
      const status = token.claims.admin === true ? 'active' : data.status;
      if (!role || status !== 'active') {
        setAccountError(status === 'pending' ? 'Your teacher account is waiting for admin approval.' : 'This account is not active. Contact the administrator.');
        setProfile(null);
      } else setProfile({ uid: current.uid, ...data, role, status, displayName: data.displayName || current.displayName || current.email });
    } catch (e) { setAccountError(e.message || 'Unable to load account.'); setProfile(null); }
    setLoading(false);
  }), []);

  const value = useMemo(() => ({ user, profile, loading, accountError }), [user, profile, loading, accountError]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
export const useAuth = () => useContext(AuthContext);

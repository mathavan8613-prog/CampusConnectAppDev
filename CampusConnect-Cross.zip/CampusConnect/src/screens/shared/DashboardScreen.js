import React from 'react';
import { Alert, FlatList, Pressable, Text, View } from 'react-native';
import { useAuth } from '../../context/AuthContext';
import { logout } from '../../services/authService';
import { styles } from '../../styles/globalStyles';
import { COLORS } from '../../styles/colors';

const MODULES = {
 student: [ ['profile','My profile','Personal and academic information'], ['attendance','Attendance','View your attendance records'], ['timetable','Timetable','Weekly class schedule'], ['exams','Exam schedule','Upcoming examinations'], ['results','Results','Published academic results'], ['materials','Study materials','Learning resources and downloads'], ['events','Events','Campus events and registration'], ['notifications','Notifications','College announcements'] ],
 teacher: [ ['students','Assigned students','Students in your assigned classes'], ['attendance','Manage attendance','Mark or review attendance'], ['timetable','Manage timetable','Create and manage class schedules'], ['exams','Manage exam schedule','Publish examination schedules'], ['results','Manage results','Enter and publish marks'], ['materials','Study materials','Upload files or add learning links'], ['events','Manage events','Create and publish events'], ['notifications','Send notifications','Send a notice to a student'] ],
 admin: [ ['students','Manage students','View student directory'], ['teachers','Manage teachers','View faculty and approval status'], ['approvals','Approve teachers','Approve or reject registrations'], ['departments','Departments','Manage departments'], ['subjects','Subjects','Manage subjects'], ['assignments','Teacher assignments','Assign teachers to classes and subjects'], ['records','Academic records','Review academic collections'], ['statistics','Dashboard statistics','View college data counts'] ]
};
export default function DashboardScreen({ navigation }) {
 const { profile } = useAuth(); const role = profile.role; const modules = MODULES[role] || [];
 const open = item => navigation.navigate('Feature', { key: item[0], title: item[1] });
 return <View style={styles.screen}><View style={{ padding: 20, paddingBottom: 10 }}><View style={styles.row}><View style={{ flex: 1 }}><Text style={styles.muted}>{role.toUpperCase()} PORTAL</Text><Text style={styles.title}>Hello, {profile.displayName?.split(' ')[0] || 'there'}!</Text><Text style={styles.subtitle}>What would you like to do today?</Text></View><Pressable onPress={() => Alert.alert('Sign out', 'Are you sure you want to sign out?', [{ text: 'Cancel' }, { text: 'Sign out', style: 'destructive', onPress: logout }])}><Text style={{ color: COLORS.danger, fontWeight: '700' }}>Logout</Text></Pressable></View></View>
 <FlatList data={modules} keyExtractor={x => x[0]} contentContainerStyle={{ padding: 20, paddingTop: 8 }} numColumns={2} columnWrapperStyle={{ gap: 12 }} renderItem={({ item, index }) => <Pressable onPress={() => open(item)} style={[styles.card, { flex: 1, minHeight: 126, justifyContent: 'space-between', borderTopWidth: 3, borderTopColor: index % 2 ? '#6B82C8' : COLORS.primary }]}><Text style={{ fontSize: 23, color: COLORS.primary }}>{['▦','◷','▤','◎'][index % 4]}</Text><View><Text style={styles.cardTitle}>{item[1]}</Text><Text style={styles.muted}>{item[2]}</Text></View></Pressable>} />
 </View>;
}

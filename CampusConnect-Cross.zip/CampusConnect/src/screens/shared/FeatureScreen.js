import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Alert, Linking, Pressable, ScrollView, Text, View } from 'react-native';
import { useAuth } from '../../context/AuthContext';
import RecordCard from '../../components/RecordCard';
import AppInput from '../../components/AppInput';
import AppButton from '../../components/AppButton';
import { styles } from '../../styles/globalStyles';
import { COLORS } from '../../styles/colors';
import * as students from '../../services/studentService';
import * as teachers from '../../services/teacherService';
import * as attendance from '../../services/attendanceService';
import * as timetable from '../../services/timetableService';
import * as exams from '../../services/examService';
import * as results from '../../services/resultService';
import * as materials from '../../services/materialsService';
import * as events from '../../services/eventsService';
import * as notifications from '../../services/notificationService';
import * as admin from '../../services/adminService';
import { pickAndUploadMaterial } from '../../services/storageService';

const pretty = v => typeof v === 'object' && v?.toDate ? v.toDate().toLocaleString() : String(v ?? '');
function Item({ item }) { const title = item.title || item.displayName || item.name || item.subjectId || item.id || 'Record'; const detail = Object.entries(item).filter(([k,v]) => !['id','createdAt','updatedAt','markedAt','readAt'].includes(k) && ['string','number','boolean'].includes(typeof v)).map(([k,v]) => `${k}: ${pretty(v)}`).join('\n'); return <RecordCard title={title} details={detail} />; }

export default function FeatureScreen({ route }) {
 const { profile } = useAuth(); const { key } = route.params; const [data,setData] = useState([]); const [loading,setLoading] = useState(true); const [busy,setBusy] = useState(false); const [error,setError] = useState('');
 const [form,setForm] = useState({ title:'', message:'', venue:'', eventDate:'', downloadURL:'', subjectId:'', day:'Mon', startTime:'09:00', endTime:'09:50', room:'', examDate:'', marks:'', maxMarks:'100', studentUid:'', examId:'', departmentId:'', code:'', name:'', teacherUid:'', semester:'1', section:'A' });
 const set = (k,v) => setForm(old => ({...old,[k]:v}));
 const load = async () => {
  setLoading(true); setError('');
  try {
   let rows=[]; const p=profile;
   switch(key) {
    case 'profile': rows=[await students.getProfile(p.uid)].filter(Boolean); break;
    case 'attendance': rows=p.role==='student' ? await attendance.forStudent(p.uid) : await teachers.myAssignments(p.uid); break;
    case 'timetable': rows=p.role==='student' ? await timetable.forStudent(p) : await timetable.forTeacher(p.uid); break;
    case 'exams': rows=p.role==='student' ? await exams.forStudent(p) : await exams.forTeacher(p.uid); break;
    case 'results': rows=p.role==='student' ? await results.forStudent(p.uid) : await results.forTeacher(p.uid); break;
    case 'materials': rows=p.role==='student' ? await materials.forStudent(p) : await materials.forTeacher(p.uid); break;
    case 'events': rows=p.role==='student' ? await events.published() : await events.mine(p.uid); break;
    case 'notifications': rows=await notifications.mine(p.uid); break;
    case 'students': rows=p.role==='teacher' ? (await teachers.myAssignments(p.uid)).flatMap(a=>[]) : await admin.students(); if(p.role==='teacher') { const as=await teachers.myAssignments(p.uid); const all=await Promise.all(as.map(teachers.listStudentsForAssignment)); rows=[...new Map(all.flat().map(s=>[s.id,s])).values()]; } break;
    case 'teachers': rows=await admin.teachers(); break;
    case 'approvals': rows=await teachers.pendingTeachers(); break;
    case 'departments': rows=await admin.departments(); break;
    case 'subjects': rows=await admin.subjects(); break;
    case 'assignments': rows=await admin.assignments(); break;
    case 'records': rows=await Promise.all(['attendance','timetables','examinations','results','studyMaterials','events'].map(async c=>({id:c,title:c,count:(await (await import('firebase/firestore')).getDocs((await import('firebase/firestore')).collection((await import('../../config/firebase')).db,c))).size}))); break;
    case 'statistics': { const counts=await Promise.all([admin.students(),admin.teachers(),admin.departments(),admin.subjects()]); rows=[{id:'stats',title:'College overview',students:counts[0].length,teachers:counts[1].length,departments:counts[2].length,subjects:counts[3].length}]; break; }
    default: rows=[];
   }
   setData(rows);
  } catch(e) { setError(e.message || 'Unable to load records.'); } finally { setLoading(false); }
 };
 useEffect(()=>{load();},[key,profile.uid]);
 const run = async fn => { setBusy(true); try { await fn(); Alert.alert('Success','Your change was saved.'); await load(); } catch(e) { Alert.alert('Unable to complete',e.message); } finally { setBusy(false); } };
 const actionForm = () => {
  if(profile.role==='teacher' && ['timetable','exams','materials','results','attendance'].includes(key)) return <View style={styles.card}><Text style={styles.cardTitle}>Teacher action</Text><Text style={styles.muted}>Choose an assignment from your assigned subjects in the current PWA-compatible data model. For attendance and result entry, use the service functions after selecting an assignment and students. This screen provides link/file and schedule entry as a starter workflow.</Text>
   {key==='materials' ? <><AppInput label="Material title" value={form.title} onChangeText={v=>set('title',v)}/><AppInput label="Subject ID" value={form.subjectId} onChangeText={v=>set('subjectId',v)}/><AppInput label="Download URL (HTTPS)" value={form.downloadURL} onChangeText={v=>set('downloadURL',v)}/><AppButton title="Upload file to Firebase Storage" variant="secondary" onPress={()=>run(async()=>{const file=await pickAndUploadMaterial(); if(file){set('downloadURL',file.downloadURL); Alert.alert('Uploaded',`File uploaded: ${file.name}. Paste its URL into the material form and save.`);}})} /><AppButton title="Save material link" loading={busy} onPress={()=>run(async()=>{const a=(await teachers.myAssignments(profile.uid)).find(x=>x.subjectId===form.subjectId); if(!a) throw new Error('Subject ID must match one of your assignments.'); await materials.createLink(profile.uid,a,form);})}/></> : <Text style={styles.body}>Use the service modules in src/services for secure class-scoped create, update and delete operations. The existing PWA security rules remain authoritative.</Text>}
  </View>;
  if(profile.role==='teacher' && key==='events') return <View style={styles.card}><Text style={styles.cardTitle}>Create event</Text><AppInput label="Title" value={form.title} onChangeText={v=>set('title',v)}/><AppInput label="Description" value={form.message} onChangeText={v=>set('message',v)} multiline/><AppInput label="Venue" value={form.venue} onChangeText={v=>set('venue',v)}/><AppInput label="Date (YYYY-MM-DD)" value={form.eventDate} onChangeText={v=>set('eventDate',v)}/><AppButton title="Publish event" loading={busy} onPress={()=>run(()=>events.create(profile.uid,{title:form.title,description:form.message,venue:form.venue,eventDate:form.eventDate,published:true}))}/></View>;
  if(profile.role==='admin' && key==='departments') return <View style={styles.card}><Text style={styles.cardTitle}>Add department</Text><AppInput label="Department name" value={form.name} onChangeText={v=>set('name',v)}/><AppInput label="Department ID" value={form.departmentId} onChangeText={v=>set('departmentId',v)}/><AppButton title="Create department" loading={busy} onPress={()=>run(()=>admin.createDepartment({name:form.name,code:form.departmentId}))}/></View>;
  if(profile.role==='admin' && key==='subjects') return <View style={styles.card}><Text style={styles.cardTitle}>Add subject</Text><AppInput label="Subject name" value={form.name} onChangeText={v=>set('name',v)}/><AppInput label="Subject code / ID" value={form.code} onChangeText={v=>set('code',v)}/><AppInput label="Department ID" value={form.departmentId} onChangeText={v=>set('departmentId',v)}/><AppInput label="Semester" value={form.semester} onChangeText={v=>set('semester',v)}/><AppButton title="Create subject" loading={busy} onPress={()=>run(()=>admin.createSubject({name:form.name,code:form.code,departmentId:form.departmentId,semester:Number(form.semester)}))}/></View>;
  if(profile.role==='admin' && key==='approvals') return <View>{data.map(t=><View key={t.id} style={styles.card}><Text style={styles.cardTitle}>{t.displayName}</Text><Text style={styles.muted}>{t.email} · {t.facultyId}</Text><View style={{flexDirection:'row',gap:10,marginTop:10}}><View style={{flex:1}}><AppButton title="Approve" onPress={()=>run(()=>teachers.setApproval(t.id,true))}/></View><View style={{flex:1}}><AppButton title="Reject" variant="secondary" onPress={()=>run(()=>teachers.setApproval(t.id,false))}/></View></View></View>)}</View>;
  return null;
 };
 return <ScrollView style={styles.screen} contentContainerStyle={styles.content}><Text style={styles.title}>{route.params.title}</Text><Text style={styles.subtitle}>Signed in as {profile.role} · {profile.displayName}</Text>
  {actionForm()}
  {loading ? <ActivityIndicator style={{marginTop:24}} color={COLORS.primary}/> : error ? <Text style={{color:COLORS.danger,marginTop:20}}>{error}</Text> : data.length ? data.map((item,i)=><View key={item.id||i}>{key==='materials' && item.downloadURL ? <Pressable onPress={()=>Linking.openURL(item.downloadURL)}><Item item={item}/><Text style={{color:COLORS.primary,marginTop:-8,marginBottom:12,fontWeight:'700'}}>Open / download material ↗</Text></Pressable> : <Item item={item}/>}</View>) : <View style={styles.card}><Text style={styles.cardTitle}>No records found</Text><Text style={styles.muted}>Records will appear here when they are available in the shared Firebase database.</Text></View>}
  <AppButton title="Refresh" variant="secondary" onPress={load}/>
  {profile.role==='admin' && key==='assignments' ? <Text style={styles.muted}>Assignment creation follows the existing PWA document ID convention teacherUid_subjectId. See backend/ASSIGNMENT_MIGRATION.md before supporting the same subject across multiple class sections.</Text> : null}
 </ScrollView>;
}

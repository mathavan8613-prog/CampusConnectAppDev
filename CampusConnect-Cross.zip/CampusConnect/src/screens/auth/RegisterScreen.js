import React, { useState } from 'react';
import { Alert, ScrollView, Text } from 'react-native';
import AppInput from '../../components/AppInput';
import AppButton from '../../components/AppButton';
import { registerStudent, registerTeacher } from '../../services/authService';
import { styles } from '../../styles/globalStyles';
export default function RegisterScreen({ navigation }) {
  const [role, setRole] = useState('student'); const [form, setForm] = useState({ displayName: '', email: '', password: '', registerNo: '', facultyId: '', departmentId: '', degree: '', year: '1', semester: '1', section: 'A', phone: '', designation: '' }); const [busy, setBusy] = useState(false);
  const set = (key, value) => setForm(old => ({ ...old, [key]: value }));
  const submit = async () => { if (!form.displayName || !form.email || form.password.length < 6 || !form.departmentId) return Alert.alert('Check details', 'Name, email, password (6+ characters), and department ID are required.'); setBusy(true); try { if (role === 'student') { if (!form.registerNo) throw new Error('Register number is required.'); await registerStudent(form); } else { if (!form.facultyId) throw new Error('Faculty ID is required.'); await registerTeacher(form); } Alert.alert('Registration submitted', role === 'teacher' ? 'Your account is pending admin approval.' : 'Your student account has been created.'); } catch (e) { Alert.alert('Registration failed', e.message); } finally { setBusy(false); } };
  return <ScrollView style={styles.screen} contentContainerStyle={styles.content}><Text style={styles.title}>Create account</Text><Text style={styles.subtitle}>Use the details registered with your college.</Text>
    <Text style={{ marginTop: 20, marginBottom: 10, color: '#243B80', fontWeight: '700' }}>Account type: {role.toUpperCase()} (edit role in this selector)</Text>
    <Text onPress={() => setRole(role === 'student' ? 'teacher' : 'student')} style={{ color: '#243B80', marginBottom: 15 }}>Switch to {role === 'student' ? 'Teacher' : 'Student'} registration</Text>
    <AppInput label="Full name" value={form.displayName} onChangeText={v => set('displayName', v)} /><AppInput label="Email" value={form.email} onChangeText={v => set('email', v)} keyboardType="email-address" /><AppInput label="Password" value={form.password} onChangeText={v => set('password', v)} secureTextEntry />
    <AppInput label="Department ID (must match Firestore)" value={form.departmentId} onChangeText={v => set('departmentId', v)} />
    {role === 'student' ? <><AppInput label="Register number" value={form.registerNo} onChangeText={v => set('registerNo', v)} /><AppInput label="Degree" value={form.degree} onChangeText={v => set('degree', v)} /><AppInput label="Year" value={form.year} onChangeText={v => set('year', v)} keyboardType="numeric" /><AppInput label="Semester" value={form.semester} onChangeText={v => set('semester', v)} keyboardType="numeric" /><AppInput label="Section" value={form.section} onChangeText={v => set('section', v)} /><AppInput label="Phone" value={form.phone} onChangeText={v => set('phone', v)} keyboardType="phone-pad" /></> : <><AppInput label="Faculty ID" value={form.facultyId} onChangeText={v => set('facultyId', v)} /><AppInput label="Designation" value={form.designation} onChangeText={v => set('designation', v)} /></>}
    <AppButton title="Submit registration" onPress={submit} loading={busy} /><Text onPress={() => navigation.goBack()} style={{ color: '#243B80', textAlign: 'center', marginTop: 20 }}>Back to login</Text>
  </ScrollView>;
}

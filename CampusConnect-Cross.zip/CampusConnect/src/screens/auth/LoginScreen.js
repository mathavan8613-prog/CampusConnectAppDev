import React, { useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, Text, Pressable, View } from 'react-native';
import { login, resetPassword, logout } from '../../services/authService';
import AppInput from '../../components/AppInput';
import AppButton from '../../components/AppButton';
import { styles } from '../../styles/globalStyles';
import { COLORS } from '../../styles/colors';
export default function LoginScreen({ navigation, accountError }) {
  const [email, setEmail] = useState(''); const [password, setPassword] = useState(''); const [busy, setBusy] = useState(false);
  const submit = async () => { if (!email.trim() || !password) return Alert.alert('Required', 'Enter your email and password.'); setBusy(true); try { await login(email, password); } catch (e) { Alert.alert('Login failed', e.message); } finally { setBusy(false); } };
  const forgot = async () => { if (!email.trim()) return Alert.alert('Email required', 'Enter your email first.'); try { await resetPassword(email); Alert.alert('Email sent', 'Check your inbox for the password reset link.'); } catch (e) { Alert.alert('Unable to send reset email', e.message); } };
  return <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={[styles.screen, { justifyContent: 'center' }]}><View style={{ padding: 24 }}>
    <View style={{ width: 58, height: 58, borderRadius: 18, backgroundColor: COLORS.primary, alignItems: 'center', justifyContent: 'center', marginBottom: 20 }}><Text style={{ color: '#fff', fontSize: 25, fontWeight: '900' }}>C</Text></View>
    <Text style={styles.title}>CampusConnect</Text><Text style={styles.subtitle}>Your campus, connected.</Text>
    {accountError ? <><Text style={{ color: COLORS.warning, marginTop: 14 }}>{accountError}</Text><Pressable onPress={logout} style={{ paddingVertical: 10 }}><Text style={{ color: COLORS.primary, fontWeight: '700' }}>Sign out of this account</Text></Pressable></> : null}
    <View style={{ marginTop: 28 }}><AppInput label="Email address" value={email} onChangeText={setEmail} keyboardType="email-address" placeholder="name@college.edu" /><AppInput label="Password" value={password} onChangeText={setPassword} secureTextEntry placeholder="Enter password" /><Pressable onPress={forgot} style={{ alignSelf: 'flex-end', paddingVertical: 5 }}><Text style={{ color: COLORS.primary, fontWeight: '600' }}>Forgot password?</Text></Pressable><AppButton title="Login" onPress={submit} loading={busy} /><Pressable onPress={() => navigation?.navigate?.('Register')} style={{ padding: 16, alignItems: 'center' }}><Text style={{ color: COLORS.primary }}>New user? Register</Text></Pressable></View>
  </View></KeyboardAvoidingView>;
}

// Teacher navigation is role-gated by RootNavigator and DashboardScreen.
export { default } from './RootNavigator';

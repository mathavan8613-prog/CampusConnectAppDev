import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useAuth } from '../context/AuthContext';
import LoadingScreen from '../components/LoadingScreen';
import LoginScreen from '../screens/auth/LoginScreen';
import RegisterScreen from '../screens/auth/RegisterScreen';
import DashboardScreen from '../screens/shared/DashboardScreen';
import FeatureScreen from '../screens/shared/FeatureScreen';
const Stack = createNativeStackNavigator();
export default function RootNavigator() {
  const { user, profile, loading, accountError } = useAuth();
  if (loading) return <LoadingScreen />;
  if (user && !profile) return <LoginScreen accountError={accountError} />;
  return <Stack.Navigator screenOptions={{ headerShown: false }}>
    {!user ? <><Stack.Screen name="Login" component={LoginScreen} /><Stack.Screen name="Register" component={RegisterScreen} /></> : <>
      <Stack.Screen name="Dashboard" component={DashboardScreen} />
      <Stack.Screen name="Feature" component={FeatureScreen} options={({ route }) => ({ headerShown: true, title: route.params?.title || 'CampusConnect', headerTintColor: '#243B80', headerStyle: { backgroundColor: '#F5F7FB' } })} />
    </>}
  </Stack.Navigator>;
}

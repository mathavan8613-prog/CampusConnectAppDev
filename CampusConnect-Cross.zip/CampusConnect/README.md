# CampusConnect Mobile

A React Native + Expo companion app for the existing CampusConnect PWA. It uses the same Firebase project and reuses the PWA collection names and document conventions where possible. The original PWA ZIP is not modified.

## Included

- Email/password login and password reset
- Student, teacher and admin role routing
- Student profile, attendance, timetable, exams, results, materials, events and notifications data views
- Teacher assigned-student lookup, attendance/timetable/exam/result/material/event/notification service modules
- Admin student/teacher/department/subject/assignment views and teacher approval workflow
- Firebase Storage upload helper for study materials
- Shared UI components, hooks, validation utilities and EAS build profiles
- Existing PWA Firestore rules copied as a review reference, not automatically deployed

This is a functional starter foundation, not a production certification. Review the backend rules, assignment migration, storage access, Firestore indexes and workflows against your real project before release. Some teacher CRUD screens are represented by service methods and focused starter forms; expand the form UX for your college's final workflow.

## 1. Requirements

- Node.js LTS (20 or newer recommended)
- npm
- Expo Go on an Android/iOS device for initial testing, or Android Studio / Xcode simulators
- Access to the Firebase project already used by your PWA

## 2. Configure Firebase

1. Open the same Firebase project used by CampusConnect PWA.
2. Copy the Firebase Web App configuration values from Firebase Console → Project settings → General → Your apps.
3. Copy `.env.example` to `.env` and fill the six `EXPO_PUBLIC_FIREBASE_*` values.
4. Do not put a service-account JSON, private key or Admin SDK credential in `.env` or the mobile project.
5. Ensure Email/Password Authentication is enabled and Firestore is the same database used by the PWA.
6. Enable Firebase Storage only if you intend to use file uploads, then review and deploy suitable Storage Rules separately.

The Firebase client config is public app configuration. Security must come from Authentication, Firestore/Storage Rules and trusted backend operations—not from hiding the client API key.

## 3. Install and run

```bash
npm install
npx expo start
```

Scan the QR code with Expo Go. Use `a` to launch an Android emulator or `i` to launch an iOS simulator (macOS with Xcode required for the iOS simulator).

You can also run:

```bash
npm run android
npm run ios
```

For a physical iPhone, use Expo Go for development; building a standalone iOS app requires macOS/Xcode or EAS Build and appropriate Apple signing credentials.

## 4. Android APK

Install and sign in to EAS CLI:

```bash
npm install -g eas-cli
eas login
eas build:configure
```

The `preview` profile in `eas.json` is configured to produce an APK:

```bash
eas build -p android --profile preview
```

EAS will provide a build URL when the cloud build completes. For Play Store distribution, use the production profile (AAB) and complete the Play Console requirements.

## 5. iOS build

```bash
eas build -p ios --profile production
```

Configure the iOS bundle identifier in `app.json` and provide Apple Developer signing credentials when prompted. iOS simulator builds can also be created through EAS with an appropriate simulator profile.

## 6. Existing PWA compatibility

The app uses these existing collections: `users`, `students`, `teachers`, `departments`, `subjects`, `teacherAssignments`, `attendance`, `timetables`, `examinations`, `results`, `studyMaterials`, `events`, `eventRegistrations`, and `notifications`.

PWA registration conventions are preserved: student users are created with `status: active`; teacher users are created with `status: pending`; administrator access is determined by the trusted Firebase custom claim `admin`.

The existing PWA stores materials as HTTPS links and does not initialize Firebase Storage. The mobile project supports both existing links and an optional Storage upload helper.

## 7. Security checklist before release

- Deploy/test Firestore Rules using the Firebase Emulator Suite.
- Confirm admin custom claims are assigned only by trusted Admin SDK code.
- Confirm teacher approval and teacher assignment writes are admin-only.
- Confirm teacher queries are constrained to assigned class/subject data. The uploaded PWA rules currently permit teachers to read all students in their department; see `backend/SECURITY_REVIEW.md` and tighten this before production.
- Confirm students cannot write attendance, timetable, exams or results.
- Add and test class-aware Storage Rules before enabling file upload. The included example denies access by default.
- Review `backend/ASSIGNMENT_MIGRATION.md` before assigning one teacher to the same subject in multiple class sections.
- Avoid caching private student records in public storage or app logs.
- Add production error reporting, audit logs, pagination and Firestore indexes as usage grows.

## 8. Project structure

```text
CampusConnect/
├── assets/
├── backend/
├── src/
│   ├── components/
│   ├── config/
│   ├── context/
│   ├── hooks/
│   ├── navigation/
│   ├── screens/
│   ├── services/
│   ├── styles/
│   └── utils/
├── App.js
├── app.json
├── babel.config.js
├── eas.json
├── package.json
├── .env.example
├── firestore.rules.reference
└── README.md
```
